
/* GÉNESIS 021–030 · Extensión demográfica y sanitaria versionada. */
(function(root){'use strict';
const STAGE=30, {GenesisEngine,DEFAULT_PERSON,DT,W,H,clamp}=root.GenesisCore;
const proto=GenesisEngine.prototype;
const prev={reset:proto.reset,step:proto.step,load:proto.load,snapshot:proto.snapshot,setPersonRules:proto.setPersonRules};
const MIN_YEAR=360*1440, MAX_PEOPLE=80;
const newCommunity=()=>({mortality:false,aging:true,illness:true,births:true,maxPopulation:40,founderCount:2,yearlyBirthRate:55,generationClock:0,history:[],nextId:3,totalBorn:2,totalDied:0,totalMigrated:0});
const extraNames=['Saeli','Orven','Naira','Elun','Thyra','Rilen','Vaeri','Zoren','Aelin','Darys','Orel','Liora','Veyra','Kiro','Selin','Nyren','Auria','Temar','Virel','Isara','Aven','Dera','Oryn','Sova','Zair','Elyn','Yara','Tarim','Vael','Oria'];
const safe=(v,a,b)=>typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b;
const clampPct=n=>clamp(Math.round(n),10,95);
function extend(p,opts={}){
 p.id=safe(opts.id,1,100000)?Math.trunc(opts.id):(p.name==='Kaelor'?1:p.name==='Ilyra'?2:0);
 p.generation=safe(opts.generation,0,100)?Math.trunc(opts.generation):0;
 p.family=typeof opts.family==='string'?opts.family.slice(0,24):'origen';
 p.parents=Array.isArray(opts.parents)?opts.parents.slice(0,2).filter(v=>Number.isInteger(v)&&v>0):[];
 p.bornMin=safe(opts.bornMin,-1e9,1e12)?opts.bornMin:0;
 p.startAge=safe(opts.startAge,0,100)?opts.startAge:(p.name==='Kaelor'?23:p.name==='Ilyra'?22:0);
 p.resilience=safe(opts.resilience,20,100)?Math.round(opts.resilience):(p.name==='Kaelor'?68:74);
 p.illness=safe(opts.illness,0,100)?opts.illness:0;
 p.injury=safe(opts.injury,0,100)?opts.injury:0;
 p.alive=opts.alive!==false;
 p.deathCause=typeof opts.deathCause==='string'?opts.deathCause.slice(0,80):'';
 p.ageBand=typeof opts.ageBand==='string'?opts.ageBand:'adulto';
 return p;
}
function currentAge(sim,p){return Math.max(0,p.startAge+(sim.community?.aging===false?0:Math.floor((sim.timeMin-p.bornMin)/MIN_YEAR)))}
function freezeInactive(sim,work){const all=sim.people;sim.people=all.filter(p=>p.alive!==false);try{return work()}finally{sim.people=all}}
proto.reset=function(...args){const result=prev.reset.apply(this,args);this.community=newCommunity();this.people.forEach(p=>extend(p));return result};
proto.setPersonRules=function(name,candidate){if(name==='Kaelor'||name==='Ilyra')return prev.setPersonRules.call(this,name,candidate);const p=this.people.find(x=>x.name===name);if(!p)throw Error('Habitante desconocido');const result={};for(const [k,min,max] of [['foodAt',10,95],['waterAt',10,95],['restAt',10,95],['metabolism',50,200],['recovery',50,200]]){const v=candidate[k];if(!Number.isInteger(v)||v<min||v>max)throw Error('Ley individual fuera de rango');result[k]=v}this.personRules[name]=result;p.target=null;p.route=[];p.decision=0;};
proto.ageOf=function(p){return currentAge(this,p)};
proto.populationStats=function(){const living=this.people.filter(p=>p.alive);return {living:living.length,founders:living.filter(p=>p.generation===0).length,descendants:living.filter(p=>p.generation>0).length,departed:this.community.totalDied,averageAge:living.length?Math.round(living.reduce((a,p)=>a+this.ageOf(p),0)/living.length):0,generations:Math.max(0,...this.people.map(p=>p.generation||0)),capacity:this.community.maxPopulation}};
proto.setCommunityOption=function(key,value){const cfg=this.community;
 if(['mortality','aging','illness','births'].includes(key)){if(typeof value!=='boolean')throw Error('Opción inválida');cfg[key]=value;}
 else if(key==='maxPopulation'){if(!Number.isInteger(value)||value<2||value>MAX_PEOPLE)throw Error('Límite entre 2 y 80');cfg.maxPopulation=value}
 else if(key==='yearlyBirthRate'){if(!Number.isInteger(value)||value<0||value>100)throw Error('Tasa fuera de rango');cfg.yearlyBirthRate=value}
 else throw Error('Opción desconocida');return true;
};
proto.setResilience=function(name,value){if(STAGE<23)throw Error('Disponible desde 023');if(!Number.isInteger(value)||value<20||value>100)throw Error('Resistencia entre 20 y 100');const p=this.people.find(p=>p.name===name);if(!p)throw Error('Habitante no encontrado');p.resilience=value;this.note(`Resistencia de ${name}: ${value}%.`);return value};
proto.loseLife=function(p,reason){if(!this.community.mortality||!p.alive)return false;p.alive=false;p.deathCause=reason;p.target=null;p.route=[];p.routeIndex=0;p.act='Fallecido';this.community.totalDied++;this.note(`${p.name} ha fallecido (${reason}).`);if(this.manualName===p.name)this.setManualName(null);return true};
proto.createFounder=function(){if(STAGE<26)throw Error('Disponible desde 026');if(this.people.length>=MAX_PEOPLE||this.people.filter(p=>p.alive).length>=this.community.maxPopulation)throw Error('Límite de habitantes alcanzado');const id=this.community.nextId++;const name='Habitante '+id;const x=this.rand(80,W-80),y=this.rand(80,H-80);const p=this.newPerson(name,['#f0cda3','#9cc4f4','#e7a5cf'][id%3],x,y);extend(p,{id,generation:0,startAge:18+Math.floor(this.rand(0,22)),resilience:45+Math.floor(this.rand(0,46)),family:'fundadores-'+id});this.people.push(p);this.personRules[name]={...DEFAULT_PERSON};this.community.totalBorn++;this.community.founderCount++;this.note(`${name} se estableció en este mundo.`);return p};
proto.createChild=function(a,b){if(STAGE<25)throw Error('Disponible desde 025');if(this.people.filter(p=>p.alive).length>=Math.min(MAX_PEOPLE,this.community.maxPopulation))return null;const id=this.community.nextId++;const name=(extraNames[(id-3)%extraNames.length]||'Vela')+' '+id;const d=this.rand(-36,36),e=this.rand(-36,36),loc=this.land(a.x+d,a.y+e);
 const p=this.newPerson(name,id%2?'#a2e8e2':'#e6c38f',loc.x,loc.y);const trait=STAGE>=27?clamp(Math.round(((a.resilience+b.resilience)/2)+this.rand(-10,10)),20,100):68;
 extend(p,{id,parents:[a.id,b.id],family:`fam-${a.id}-${b.id}`,generation:Math.max(a.generation,b.generation)+1,bornMin:this.timeMin,startAge:0,resilience:trait});
 this.people.push(p);const lawA=this.personRules[a.name]||DEFAULT_PERSON,lawB=this.personRules[b.name]||DEFAULT_PERSON;
 this.personRules[p.name]=STAGE>=27?Object.fromEntries(Object.keys(DEFAULT_PERSON).map(k=>[k,k==='metabolism'||k==='recovery'?clamp(Math.round((lawA[k]+lawB[k])/2+this.rand(-6,6)),50,200):clampPct((lawA[k]+lawB[k])/2+this.rand(-6,6))])):{...DEFAULT_PERSON};
 this.community.totalBorn++;this.note(`Nueva generación: nació ${name}.`);return p;
};
proto.yearlyPopulation=function(){const cfg=this.community;const living=this.people.filter(p=>p.alive);if(STAGE>=22&&cfg.aging){for(const p of living){const age=this.ageOf(p);if(age>60){p.vitality=clamp(p.vitality-(age-55)*.12,0,100);if(cfg.mortality&&(age>100||p.vitality<=0||this.next()<Math.min(.35,Math.max(0,age-66)*.009)))this.loseLife(p,'edad avanzada')}}}
 if(STAGE>=24&&cfg.illness){for(const p of living){if(!p.alive)continue;if(this.next()<.06){p.illness=clamp(p.illness+this.rand(12,35),0,100);this.note(`${p.name} presenta una enfermedad simulada.`)}p.illness=clamp(p.illness-(p.resilience/100)*this.rand(8,35),0,100);p.injury=clamp(p.injury-(p.resilience/100)*this.rand(8,30),0,100)}}
 if(STAGE>=25&&cfg.births){const candidates=this.people.filter(p=>p.alive&&this.ageOf(p)>=18&&this.ageOf(p)<52);if(candidates.length>=2&&this.people.filter(p=>p.alive).length<cfg.maxPopulation){const regionFactor=STAGE>=28?clamp((this.bushes.length/110)*(this.nature?.moisture||70)/70,.10,1.5):1;let attempts=Math.min(3,Math.floor(candidates.length/2));for(let i=0;i<attempts;i++){if(this.next()<cfg.yearlyBirthRate/100*regionFactor){const parents=[candidates[Math.floor(this.next()*candidates.length)],candidates[Math.floor(this.next()*candidates.length)]];if(parents[0].id===parents[1].id)parents[1]=candidates.find(x=>x.id!==parents[0].id);if(parents[1])this.createChild(parents[0],parents[1])}}}}
 if(STAGE>=29){for(const p of this.people){if(!p.alive||this.next()>.14)continue;let place=null,score=-Infinity;for(let j=0;j<9;j++){const x=this.rand(30,W-30),y=this.rand(30,H-30),b=this.biomeAt(x,y);if(!this.walkable(x,y))continue;const val=({bosque:4,pradera:3,sabana:2,colina:1,tundra:-1,desierto:-2})[b]||0;if(val>score){score=val;place={x,y}}}if(place&&Math.hypot(place.x-p.x,place.y-p.y)>110){p.x=place.x;p.y=place.y;p.target=null;p.route=[];p.decision=0;cfg.totalMigrated++}}}
 if(STAGE>=28){const active=this.people.filter(p=>p.alive);const dense=active.length/Math.max(1,this.bushes.length);if(dense>.38)for(const p of active){p.hunger=clamp(p.hunger-12,0,100);if(this.next()<.15)p.vitality=clamp(p.vitality-8,0,100)}}
 cfg.generationClock++;
};
proto.advanceYears=function(years=1){if(STAGE<22)throw Error('Disponible desde 022');if(!Number.isInteger(years)||years<1||years>25)throw Error('Entre 1 y 25 años');for(let j=0;j<years;j++){this.timeMin+=MIN_YEAR;this.yearlyPopulation()}this.note(`Se avanzaron ${years} año(s) por estimación demográfica.`);return this.populationStats()};
proto.step=function(dt=DT){const orig=this.people;let before=Math.floor(this.timeMin/MIN_YEAR);if(this.community?.mortality){this.people=orig.filter(p=>p.alive!==false)}try{prev.step.call(this,dt)}finally{this.people=orig}
 if(!this.community)return;
 if(STAGE>=21){for(const p of this.people){if(p.alive===false)continue;const low=Number(p.hunger<10)+Number(p.thirst<10)+Number(p.energy<6);if(low&&p.vitality<=1){if(this.community.mortality)this.loseLife(p,'escasez prolongada');else p.vitality=1;}}}
 if(STAGE>=24&&this.community.illness){for(const p of this.people){if(!p.alive)continue;if(p.illness>0||p.injury>0)p.vitality=clamp(p.vitality-dt*(p.illness*.0018+p.injury*.0007),0,100);p.illness=clamp(p.illness-dt*p.resilience*.0003,0,100);p.injury=clamp(p.injury-dt*p.resilience*.0002,0,100);if(this.community.mortality&&p.vitality<=0)this.loseLife(p,'salud debilitada')}}
 if(STAGE>=22){const after=Math.floor(this.timeMin/MIN_YEAR);if(after>before)for(let i=0;i<Math.min(2,after-before);i++)this.yearlyPopulation()}
};
proto.snapshot=function(){const all=this.people;this.people=all.slice(0,2);let s;try{s=prev.snapshot.call(this)}finally{this.people=all} s.version=STAGE;s.release=String(STAGE).padStart(3,'0');s.people=JSON.parse(JSON.stringify(all));s.personRules=JSON.parse(JSON.stringify(this.personRules));s.community=JSON.parse(JSON.stringify(this.community));return s};
proto.load=function(raw){if(!raw||typeof raw!=='object')throw Error('Mundo no válido');let legacy=raw;if(raw.version>=21&&raw.version<=STAGE){if(!Array.isArray(raw.people)||raw.people.length<2||raw.people.length>MAX_PEOPLE)throw Error('Población incompatible');if(!raw.community||typeof raw.community!=='object'||!Number.isInteger(raw.community.nextId)||raw.community.nextId<3||raw.community.nextId>100000)throw Error('Datos demográficos no válidos');for(const p of raw.people){if(!p||typeof p.name!=='string'||p.name.length>50||!safe(p.x,0,W)||!safe(p.y,0,H)||!safe(p.hunger,0,100)||!safe(p.thirst,0,100)||!safe(p.energy,0,100)||!safe(p.vitality,0,100)||!safe(p.resilience,20,100))throw Error('Habitante incompatible');if(p.alive!==true&&p.alive!==false)throw Error('Estado vital inválido');}
 legacy={...raw,version:20,people:raw.people.slice(0,2),personRules:{Kaelor:raw.personRules?.Kaelor,Ilyra:raw.personRules?.Ilyra}};
 }
 prev.load.call(this,legacy);this.community=newCommunity();this.people.forEach((p,i)=>extend(p,raw.version>=21?raw.people[i]:{}));
 if(raw.version>=21){const cfg=raw.community;for(const key of ['mortality','aging','illness','births'])if(typeof cfg[key]==='boolean')this.community[key]=cfg[key];for(const [k,lo,hi] of [['maxPopulation',2,MAX_PEOPLE],['founderCount',2,MAX_PEOPLE],['yearlyBirthRate',0,100],['generationClock',0,1e7],['nextId',3,100000],['totalBorn',2,1e7],['totalDied',0,1e7],['totalMigrated',0,1e7]])if(Number.isInteger(cfg[k])&&cfg[k]>=lo&&cfg[k]<=hi)this.community[k]=cfg[k];
 this.community.history=Array.isArray(cfg.history)?cfg.history.slice(-50).filter(x=>typeof x==='string').map(x=>x.slice(0,120)):[];
 for(const p of raw.people.slice(2)){if(this.people.some(x=>x.name===p.name)||!/^([\p{L}0-9 -]+)$/u.test(p.name))throw Error('Nombre de habitante inválido');const created=extend(this.newPerson(p.name,p.color||'#bce2d5',p.x,p.y),p);for(const k of ['hunger','thirst','energy','vitality'])created[k]=p[k];created.target=null;created.route=[];created.decision=0;this.people.push(created);
 const law=raw.personRules?.[p.name];this.personRules[p.name]={...DEFAULT_PERSON};if(law)this.setPersonRules(p.name,law);
 }
 }
 this.personRules.Kaelor={...this.personRules.Kaelor};this.personRules.Ilyra={...this.personRules.Ilyra};
};
root.GenesisDemography={stage:STAGE,MAX_PEOPLE,MIN_YEAR};
})(typeof globalThis!=='undefined'?globalThis:this);
