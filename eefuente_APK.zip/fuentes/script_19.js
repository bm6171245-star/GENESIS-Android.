
/* GÉNESIS 071–080 · Un solo panel sencillo para línea temporal */
(function(){'use strict';
const api=window.GenesisNatureAccess,mod=window.GenesisChronicle;if(!api||!mod)return;const sim=api.sim,STAGE=mod.stage;
const items=[
 ['capsule',71,'Guardar una instantánea'],['fork',72,'Crear universo alternativo'],['switch',72,'Cambiar de universo'],
 ['rate',73,'Cambiar velocidad del tiempo'],['jump',74,'Avanzar años simulados'],['restore',75,'Restaurar una instantánea'],
 ['offline',76,'Avance al regresar'],['cycle',77,'Modo de civilizaciones'],['era',78,'Comenzar una nueva era'],
 ['timeline',79,'Consultar cronología'],['compare',80,'Comparar universos']
];
const $=(id)=>document.getElementById(id),node=(tag,cls,txt)=>{const x=document.createElement(tag);if(cls)x.className=cls;if(txt!==undefined)x.textContent=txt;return x};
function render(host){host.replaceChildren();host.append(node('p','historyIntro','Tiempo e historia · una acción a la vez. Los saltos históricos son estimaciones simplificadas.'));
 const line=node('label','historyLine');line.append(node('span','','¿Qué quieres hacer?'));
 const select=node('select');for(const [v,min,txt] of items.filter(x=>x[1]<=STAGE)){const o=node('option','',txt);o.value=v;select.append(o)}line.append(select);host.append(line);
 const param=node('div');host.append(param);
 const run=node('button','historyRun','Realizar acción');run.type='button';host.append(run);
 const report=node('div','historyReport');report.setAttribute('aria-live','polite');host.append(report);
 const summary=()=>{const s=sim.chronoStats(),h=sim.chronicle;return `Era ${h.era} · Año ${s.year} · ${s.living} habitantes activos\nInstantáneas: ${h.capsules.length}/3 · Universos alternativos: ${h.branches.length}/3\n\nÚltimos cambios:\n${h.events.slice(0,4).map(e=>`• Año ${e.year}: ${e.text}`).join('\n')||'Sin modificaciones históricas'}`};
 const extra=(values,defaultVal)=>{const se=node('select');for(const [val,name] of values){const o=node('option','',name);o.value=val;se.append(o)}if(defaultVal!==undefined)se.value=defaultVal;param.append(se);return se};
 const options=()=>{param.replaceChildren();const t=select.value;run.textContent=t==='timeline'||t==='compare'?'Consultar':'Realizar acción';
 if(t==='restore')extra(sim.chronicle.capsules.map(x=>[x.id,`${x.title} · año ${x.year}`]));
 if(t==='switch')extra([['principal','Universo principal'],...sim.chronicle.branches.map(x=>[x.id,x.title])],sim.chronicle.activeBranch);
 if(t==='rate')extra([['0.5','Lento 0,5×'],['1','Normal 1×'],['2','Rápido 2×'],['4','Muy rápido 4×'],['8','Máximo 8×']],'1');
 if(t==='jump')extra([['10','10 años'],['100','100 años'],['1000','1000 años']]);
 if(t==='cycle')extra([['manual','Intervenir manualmente'],['reiniciar','Nueva era al desaparecer la población'],['continuar','Mantener el planeta vacío']],sim.chronicle.cycle);
 if(t==='offline'){extra([['off','No calcular al regresar'],['1','1 año por día real'],['7','7 años por día real'],['30','30 años por día real']],sim.chronicle.offline?String(sim.chronicle.yearsPerDay):'off');param.append(node('small','historyTip',`Avance pendiente calculado: ${sim.chronoOfflineEstimate()} años. Se aplica solo cuando lo confirmas.`));}
 if(['capsule','fork'].includes(t)){const field=node('input');field.maxLength=65;field.placeholder=t==='capsule'?'Nombre de la instantánea':'Nombre del universo';field.value=t==='capsule'?'Recuerdo del año '+sim.chronoStats().year:'Universo alternativo';param.append(field)};
 };select.onchange=options;options();report.textContent=summary();
 run.onclick=()=>{try{const choice=select.value,v=param.querySelector('select')?.value,input=param.querySelector('input')?.value||'';
 if(choice==='capsule')sim.chronoCapsule(input);
 if(choice==='fork')sim.chronoFork(input);
 if(choice==='switch'){if(!v)throw Error('Primero crea otro universo');if(!confirm('Cambiar de universo? El mundo actual se conservará en la rama, pero este panel cambiará el mapa.'))return;sim.chronoSwitch(v)}
 if(choice==='rate'){$('timeRate').value=v;$('timeRate').dispatchEvent(new Event('change',{bubbles:true}));}
 if(choice==='jump'){if(!confirm('Avanzar '+v+' años por estimación de población, sin simular cada día?'))return;sim.chronoAdvance(Number(v));}
 if(choice==='restore'){if(!v)throw Error('Guarda primero una instantánea');if(!confirm('Volver a ese estado? Las acciones posteriores se perderán si no las guardaste en otro universo.'))return;sim.chronoRestore(v)}
 if(choice==='offline'){sim.chronicle.offline=v!=='off';if(v!=='off')sim.chronicle.yearsPerDay=Number(v);const years=sim.chronoOfflineEstimate();if(years&&confirm(`Aplicar ${years} años aproximados del tiempo transcurrido fuera?`))sim.chronoApplyOffline();}
 if(choice==='cycle')sim.chronoSetCycle(v);
 if(choice==='era'){if(!confirm('Crear una nueva era? El mundo actual se reiniciará. Guarda una instantánea o universo alternativo si deseas volver.'))return;sim.chronoNewEra();}
 if(choice==='timeline'){report.textContent='CRONOLOGÍA\n'+sim.chronoTimeline().map(e=>`Año ${e.year} · ${e.text}`).join('\n');return}
 if(choice==='compare'){report.textContent='COMPARACIÓN\n'+sim.chronoCompare().map(s=>`${s.title}: año ${s.year}, ${s.living} vivos, ${s.settlements} aldeas, investigación ${s.research}`).join('\n');return}
 api.view?.createTerrain?.();api.view?.draw?.();api.view?.drawMinimap?.();api.persist(true);options();report.textContent=summary();
 }catch(e){report.textContent='No se completó: '+e.message+'\n\n'+summary()}};
}
// Registrar último cierre antes del autoguardado ya existente (listener burbujeante).
document.addEventListener('visibilitychange',()=>{if(document.hidden){sim.chronicle.lastSeenAt=Date.now();api.persist(true)}},true);
window.addEventListener('pagehide',()=>{sim.chronicle.lastSeenAt=Date.now();api.persist(true)});
window.GenesisChronicleUI={render,stage:STAGE,sim};
})();

