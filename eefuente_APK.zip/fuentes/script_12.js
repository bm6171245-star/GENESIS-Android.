
/* GÉNESIS: control ambiental incrustado en la interfaz existente */
(function(){'use strict';const stage=window.GenesisNatureVersion,$=id=>document.getElementById(id),api=window.GenesisNatureAccess;if(!api)return;
const {sim,view,persist,note}=api;
let lastBiomeTick=-1;
for(const el of document.querySelectorAll('#naturePanel [data-from]'))if(Number(el.dataset.from)>stage)el.hidden=true;
function refreshTerrain(){view.createTerrain();view.draw();view.drawMinimap()}
function sync(){const n=sim.nature;if(!n)return;
 $('natureWeatherValue').textContent=stage>=13?n.weather:'Sin clima';$('natureSeason').textContent=stage>=14?sim.seasonName()+' · '+Math.round(n.temperature)+'°C':'No activo';$('natureMoisture').textContent=stage>=15?Math.round(n.moisture)+' %':'No activo';$('natureAnimals').textContent=stage>=17?n.animals.length:'No activo';
 $('natureDrought').checked=!!n.drought;$('natureEvents').checked=!!n.events;$('natureWorldType').value=n.worldType;
 if(stage>=12&&sim.tick-lastBiomeTick>=100){lastBiomeTick=sim.tick;const counts={};for(let y=40;y<960;y+=60)for(let x=40;x<1440;x+=60){const b=sim.biomeAt(x,y);counts[b]=(counts[b]||0)+1}const sorted=Object.entries(counts).sort((a,b)=>b[1]-a[1]);$('natureBiomes').textContent='Biomas aproximados del mapa: '+sorted.map(([b,c])=>b+' '+Math.round(c/384*100)+' %').join(' · ')}
}
function message(s){$('natureMessage').textContent=s;note(s)}
function action(fn){try{fn();sync();persist(true);view.draw();view.drawMinimap()}catch(e){message('No se aplicó el cambio: '+e.message)}}
window.GenesisNatureTools={selectedTool:'',update:sync,paint(p){return action(()=>{sim.paintCell(p.x,p.y,$('natureBrush').value);refreshTerrain();message('Terreno cambiado a '+$('natureBrush').value+'.')})}};
$('natureBrush').addEventListener('change',()=>{window.GenesisNatureTools.selectedTool=$('natureBrush').value;message(window.GenesisNatureTools.selectedTool?'Seleccionado '+window.GenesisNatureTools.selectedTool+'. Activa Creador y toca el mapa.':'Pincel desactivado.')});
$('natureCreator').onclick=()=>{api.setMode('creator');message('Modo Creador activado. Selecciona un bioma y toca el mapa.')};
$('naturePaintCenter').onclick=()=>action(()=>{const b=$('natureBrush').value;if(!b)throw Error('Elige un bioma primero');sim.paintCell(view.camera.x,view.camera.y,b);refreshTerrain();message('Terreno modificado en el centro de la cámara.')});
$('natureRefreshWeather').onclick=()=>action(()=>{const selected=$('natureWeather').value;sim.nature.weather=selected==='auto'?['Despejado','Nublado','Lluvia'][Math.floor(sim.next()*3)]:selected;sim.nature.weatherTimer=0;message('Clima: '+sim.nature.weather)});
$('natureDrought').onchange=()=>action(()=>{sim.nature.drought=$('natureDrought').checked;message('Sequía '+(sim.nature.drought?'activada':'desactivada'))});
$('natureWater').onclick=()=>action(()=>{sim.nature.moisture=Math.min(100,sim.nature.moisture+15);message('Humedad aumentada')});
$('natureAddAnimals').onclick=()=>action(()=>{const n=sim.addAnimals(4);message('Añadidos '+n+' animales virtuales')});
$('natureEvents').onchange=()=>action(()=>{sim.nature.events=$('natureEvents').checked;message('Fenómenos automáticos '+(sim.nature.events?'activados':'desactivados'))});
$('natureStorm').onclick=()=>action(()=>{sim.triggerEvent('tormenta');message('Tormenta: aumentó la humedad')});
$('natureDry').onclick=()=>action(()=>{sim.triggerEvent('sequia');message('Sequía: disminuyó la humedad')});
$('natureApplyWorld').onclick=()=>action(()=>{sim.setWorldType($('natureWorldType').value);refreshTerrain();message('Planeta configurado como '+sim.nature.worldType)});
const oldDraw=view.draw.bind(view);view.draw=function(){oldDraw();if(stage>=17&&sim.nature?.animals?.length){const g=this.ctx,c=this.camera,scale=c.scale*this.canvas.width/Math.max(1,this.canvas.clientWidth);g.save();g.setTransform(scale,0,0,scale,this.canvas.width/2-c.x*scale,this.canvas.height/2-c.y*scale);for(const a of sim.nature.animals){g.fillStyle='#d7b98b';g.beginPath();g.ellipse(a.x,a.y,5,3,0,0,7);g.fill();g.fillStyle='#f4e2ac';g.fillRect(a.x-1,a.y-2,2,3)}g.restore()}}
const oldTerrain=view.createTerrain.bind(view);view.createTerrain=function(){oldTerrain();const g=this.terrain.getContext('2d');const colors={bosque:'#2b7655',pradera:'#679460',desierto:'#bca36d',colina:'#838c77',agua:'#287b94',tundra:'#9fb9b5',sabana:'#b9ae67'};for(const [key,t] of Object.entries(sim.nature?.tiles||{})){const [tx,ty]=key.split(',').map(Number);g.fillStyle=colors[t]||'#66856c';g.fillRect(tx*24,ty*24,24,24);g.strokeStyle='#ffffff24';g.strokeRect(tx*24+.5,ty*24+.5,23,23)}if(stage>=19&&sim.nature?.worldType!=='realista'){const g=this.terrain.getContext('2d');g.save();g.globalCompositeOperation='screen';g.fillStyle=sim.nature.worldType==='fantastico'?'#622baa32':'#1889ab19';g.fillRect(0,0,1440,960);g.restore()}}
if(stage>=19)refreshTerrain();sync();
window.GenesisNatureDebug={stage,paint:(x,y,b)=>{sim.paintCell(x,y,b);refreshTerrain();return sim.biomeAt(x,y)},setWeather:w=>{sim.nature.weather=w;sync()},weather:()=>sim.nature.weather,biome:(x,y)=>sim.biomeAt(x,y),animals:()=>sim.nature.animals.length,trigger:k=>sim.triggerEvent(k),setWorld:t=>{sim.setWorldType(t);refreshTerrain()},nature:()=>JSON.parse(JSON.stringify(sim.nature)),refresh:sync};
})();
