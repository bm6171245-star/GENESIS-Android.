
/* GÉNESIS 071-080: línea temporal experimental y mundos alternativos. */
(function(root){'use strict';
const STAGE=80, Core=root.GenesisCore, proto=Core.GenesisEngine.prototype;
const original={reset:proto.reset,load:proto.load,snapshot:proto.snapshot,step:proto.step};
const YEAR=360*1440;const MAX_CAPSULES=3,MAX_BRANCHES=3,MAX_EVENTS=100;
const copy=v=>JSON.parse(JSON.stringify(v));
const initial=()=>({era:1,cycle:'manual',activeBranch:'principal',principalState:null,capsules:[],branches:[],events:[],serial:1,offline:false,yearsPerDay:1,lastSeenAt:null});
const yearOf=s=>Math.floor(s.timeMin/YEAR)+1;
function baseState(s){let o=original.snapshot.call(s);o.version=70;o.release='070';delete o.chronicle;return o}
function compactStat(s){const living=s.people.filter(p=>p.alive!==false).length;return{year:yearOf(s),living,people:s.people.length,settlements:s.civilization?.settlements?.length||0,research:s.technology?.research||0,workshops:s.technology?.workshops?.length||0,era:s.chronicle?.era||1}}
function log(s,message,kind='tiempo'){
 const a=s.chronicle;if(!a)return;
 a.events.unshift({id:a.serial++,year:yearOf(s),kind,text:String(message).slice(0,180)});
 a.events=a.events.slice(0,MAX_EVENTS);
}
function withRestore(s,state){const ledger=s.chronicle;original.load.call(s,copy(state));s.chronicle=ledger}
function checkpointData(s){const state=baseState(s);return {state,stats:compactStat(s)}}
function limited(text,n){return String(text||'').trim().slice(0,n)}
function verify(raw){
 const out=initial();if(raw===undefined)return out;
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Registro temporal incorrecto');
 if(!Number.isInteger(raw.era)||raw.era<1||raw.era>100000)throw Error('Era incompatible');out.era=raw.era;
 if(['manual','reiniciar','continuar'].includes(raw.cycle))out.cycle=raw.cycle;
 if(typeof raw.activeBranch==='string'&&raw.activeBranch.length<=60)out.activeBranch=raw.activeBranch;
 if(Number.isInteger(raw.serial)&&raw.serial>=1&&raw.serial<10000000)out.serial=raw.serial;
 if(typeof raw.offline==='boolean')out.offline=raw.offline;
 if([1,7,30].includes(raw.yearsPerDay))out.yearsPerDay=raw.yearsPerDay;
 if(Number.isFinite(raw.lastSeenAt)&&raw.lastSeenAt>0)out.lastSeenAt=raw.lastSeenAt;
 const arr=(key,max)=>{if(raw[key]===undefined)return [];if(!Array.isArray(raw[key])||raw[key].length>max)throw Error('Demasiados registros en '+key);return raw[key]};
 out.events=arr('events',MAX_EVENTS).map(e=>{if(!e||typeof e.text!=='string'||e.text.length>180||!Number.isInteger(e.year)||e.year<1||e.year>1e8)throw Error('Evento inválido');return{id:Number(e.id)||0,year:e.year,kind:limited(e.kind,20),text:e.text}});
 const checkState=(entry)=>{if(!entry||typeof entry.id!=='string'||entry.id.length>60||!entry.state||typeof entry.state!=='object')throw Error('Instantánea inválida');const state=entry.state;if(state.chronicle!==undefined||state.version!==70||!Array.isArray(state.people)||state.people.length>80)throw Error('La instantánea tiene formato incorrecto');return{id:entry.id,title:limited(entry.title,70),year:Number(entry.year)||1,stats:entry.stats||{},state}};
 if(raw.principalState!==undefined&&raw.principalState!==null){const a=raw.principalState;if(!a||a.version!==70||a.chronicle!==undefined||!Array.isArray(a.people)||a.people.length>80)throw Error('Mundo principal inválido');out.principalState=a}
 out.capsules=arr('capsules',MAX_CAPSULES).map(checkState);
 out.branches=arr('branches',MAX_BRANCHES).map(checkState);
 return out;
}
proto.reset=function(...args){const r=original.reset.apply(this,args);this.chronicle=initial();return r};
proto.snapshot=function(){const state=original.snapshot.call(this);state.version=STAGE;state.release=String(STAGE).padStart(3,'0');state.chronicle=copy(this.chronicle);return state};
proto.load=function(raw){if(!raw||typeof raw!=='object')throw Error('Partida no válida');const ver=Number(raw.version);if(ver>STAGE)throw Error('Esta partida necesita una versión más reciente');const clock=ver>=71?verify(raw.chronicle):initial();const legacy=ver>=71?{...raw,version:70}:raw;original.load.call(this,legacy);this.chronicle=clock};
proto.chronoStats=function(){return compactStat(this)};
proto.chronoTimeline=function(){const a=this.chronicle.events.map(e=>({...e}));if(this.heritage?.events)for(const e of this.heritage.events.slice(-80))a.push({id:'h'+e.id,year:e.year||1,kind:e.type||'cultura',text:limited(e.text,150)});return a.sort((x,y)=>y.year-x.year).slice(0,65)};
proto.chronoCapsule=function(title){if(STAGE<71)throw Error('Función futura');const c=this.chronicle;if(c.capsules.length>=MAX_CAPSULES)throw Error('Máximo tres instantáneas. Elimina una antes.');const id='cap-'+c.serial++;const d=checkpointData(this);c.capsules.push({id,title:limited(title,65)||'Año '+d.stats.year,year:d.stats.year,...d});log(this,'Guardó instantánea '+id,'instantanea');return id};
proto.chronoDeleteCapsule=function(id){const b=this.chronicle.capsules;const i=b.findIndex(x=>x.id===id);if(i<0)throw Error('No existe');b.splice(i,1);log(this,'Eliminó instantánea '+id);};
proto.chronoRestore=function(id){if(STAGE<75)throw Error('Disponible desde 075');const point=this.chronicle.capsules.find(x=>x.id===id);if(!point)throw Error('Selecciona una instantánea');const previous=checkpointData(this);try{withRestore(this,point.state)}catch(e){try{withRestore(this,previous.state)}catch(_){}throw e}log(this,'Restauró instantánea del año '+point.year,'restauracion');return this.chronoStats()};
proto.chronoFork=function(title){if(STAGE<72)throw Error('Disponible desde 072');const a=this.chronicle;if(a.branches.length>=MAX_BRANCHES)throw Error('Máximo tres ramas.');const stats=this.chronoStats();const id='rama-'+a.serial++;a.branches.push({id,title:limited(title,65)||'Universo '+id,year:stats.year,stats,state:baseState(this)});log(this,'Creó universo alternativo '+id,'rama');return id};
proto.chronoSwitch=function(id){if(STAGE<72)throw Error('Disponible desde 072');const a=this.chronicle;if(id===a.activeBranch)return this.chronoStats();
 const target=id==='principal'?a.principalState:a.branches.find(b=>b.id===id)?.state;
 if(!target)throw Error('No existe un estado para ese universo');
 const from=baseState(this),oldActive=a.activeBranch;
 try{withRestore(this,target)}catch(e){try{withRestore(this,from)}catch(_){}throw e}
 if(oldActive==='principal')a.principalState=from;
 else{const previous=a.branches.find(b=>b.id===oldActive);if(previous){previous.state=from;previous.stats={year:Math.floor(from.timeMin/YEAR)+1,living:from.people.filter(p=>p.alive!==false).length,people:from.people.length,settlements:from.civilization?.settlements?.length||0,research:from.technology?.research||0,workshops:from.technology?.workshops?.length||0,era:a.era}}}
 a.activeBranch=id;log(this,'Abrió universo '+(id==='principal'?'principal':a.branches.find(b=>b.id===id).title),'rama');return this.chronoStats()};
proto.chronoAdvance=function(years){if(STAGE<74)throw Error('Disponible desde 074');if(![10,100,1000].includes(years))throw Error('Elige 10, 100 o 1000 años');if(yearOf(this)+years>300000)throw Error('Límite de 300.000 años simulados');for(let i=0;i<years;i+=25)this.advanceYears(Math.min(25,years-i));log(this,'Avance demográfico aproximado de '+years+' años','salto');return this.chronoStats()};
proto.chronoOfflineEstimate=function(now=Date.now()){
 const t=this.chronicle;if(STAGE<76||!t.offline||!t.lastSeenAt)return 0;
 const days=Math.max(0,(now-t.lastSeenAt)/86400000);
 return Math.min(25,Math.floor(days*t.yearsPerDay));
};
proto.chronoApplyOffline=function(now=Date.now()){
 if(STAGE<76)throw Error('Disponible desde 076');const n=this.chronoOfflineEstimate(now);if(n>0)for(let i=0;i<n;i++)this.advanceYears(1);this.chronicle.lastSeenAt=null;if(n)log(this,'Calculó '+n+' año(s) al regresar (aproximación demográfica)','regreso');return n;
};
proto.chronoSetCycle=function(mode){if(STAGE<77)throw Error('Disponible desde 077');if(!['manual','reiniciar','continuar'].includes(mode))throw Error('Modo no válido');this.chronicle.cycle=mode;log(this,'Ciclo de civilizaciones: '+mode);return mode};
proto.chronoNewEra=function(){if(STAGE<78)throw Error('Disponible desde 078');const ledger=this.chronicle;const prior=this.chronoStats();const freshSeed=((this.seed+this.tick+ledger.serial*24691)>>>0)||1;original.reset.call(this,freshSeed,this.terrainPreset);this.chronicle=ledger;ledger.era++;log(this,'Comenzó una nueva era después del año '+prior.year,'era');return this.chronoStats()};
proto.chronoCompare=function(){if(STAGE<80)throw Error('Disponible desde 080');const a=this.chronicle;return[{title:'Mundo activo',...this.chronoStats()},...(a.principalState?[{title:'Mundo principal guardado',year:Math.floor(a.principalState.timeMin/YEAR)+1,living:a.principalState.people.filter(p=>p.alive!==false).length,settlements:a.principalState.civilization?.settlements?.length||0,research:a.principalState.technology?.research||0}]:[]),...a.branches.filter(b=>b.id!==a.activeBranch).map(b=>({title:b.title,...b.stats})),...a.capsules.map(c=>({title:c.title,...c.stats}))]};
proto.step=function(...args){const result=original.step.apply(this,args);const h=this.chronicle;if(h&&STAGE>=77&&h.cycle==='reiniciar'&&this.people.filter(p=>p.alive!==false).length===0){const era=h.era;const nextSeed=((this.seed+this.tick+1327)>>>0)||1;original.reset.call(this,nextSeed,this.terrainPreset);this.chronicle=h;h.era=era+1;log(this,'Reinicio automático tras desaparición de población','era')}return result};
root.GenesisChronicle={stage:STAGE,MAX_CAPSULES,MAX_BRANCHES};
})(typeof globalThis!=='undefined'?globalThis:this);

