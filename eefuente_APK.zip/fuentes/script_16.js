
(function(){'use strict';
 const api=window.GenesisNatureAccess;if(!api||!window.GenesisVisual)return;
 const view=api.view;let quality='equilibrado';
 try{const pref=localStorage.getItem('genesis050_graphics_quality');if(['economico','equilibrado','alto'].includes(pref))quality=pref}catch{}
 const previous=view.createTerrain.bind(view);
 view.createTerrain=function(){
  if(quality==='economico'){previous();return}
  this.terrain=window.GenesisVisual.buildTerrain(api.sim,quality);
 };
 function redraw(){view.createTerrain();view.draw();view.drawMinimap()}
 const controls=document.querySelector('[data-page="controles"]')||document.querySelector('.drawerScroll');
 if(controls){
  const box=document.createElement('section');box.className='panel';box.id='visualGraphicsPanel';box.style.marginBottom='12px';box.innerHTML='<h2 style="margin:0 0 8px">Calidad de gráficos</h2><p style="color:#a3c7b7;font-size:11px">Solo modifica el dibujo; no altera decisiones ni partidas.</p><label for="graphicsQuality" style="display:block;margin:8px 0 5px;font-size:12px">Nivel de detalle</label><select id="graphicsQuality" style="width:100%;background:#183c35;color:#f1f7e9;border:1px solid #588a78;border-radius:9px;min-height:42px;padding:9px"><option value="economico">Económico · máximo rendimiento</option><option value="equilibrado">Equilibrado · recomendado</option><option value="alto">Alto · más vegetación y texturas</option></select>';
  controls.prepend(box);const select=box.querySelector('select');select.value=quality;select.addEventListener('change',()=>{quality=select.value;try{localStorage.setItem('genesis050_graphics_quality',quality)}catch{};redraw()});
 }
 redraw();window.GenesisGraphicsDebug={quality:()=>quality,setQuality:q=>{if(!['economico','equilibrado','alto'].includes(q))throw Error('Calidad incorrecta');quality=q;const sel=document.querySelector('#graphicsQuality');if(sel)sel.value=q;redraw()},getTerrain:()=>view.terrain};
})();
