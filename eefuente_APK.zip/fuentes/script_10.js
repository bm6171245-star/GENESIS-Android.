
/* GÉNESIS 008 · Visualización de rutas y cámara, sin alterar el motor. */
(function(root){'use strict';
const {W,H,clamp}=root.GenesisCore;
class GenesisView{
 constructor(canvas,minimap,sim){this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:false});this.minimap=minimap;this.miniCtx=minimap.getContext('2d');this.sim=sim;this.camera={x:W/2,y:H/2,scale:1.1};this.follow='both';this.showDestinations=true;this.createTerrain();this.resize()}
 createTerrain(){
   const terrain=document.createElement('canvas');terrain.width=W;terrain.height=H;
   const g=terrain.getContext('2d');let rngState=(this.sim.seed^0x9e3779b9)>>>0;
   const next=()=>{rngState=(Math.imul(1664525,rngState)+1013904223)>>>0;return rngState/4294967296};
   const range=(a,b)=>a+next()*(b-a);
   const paint={agua:['#27677a','#34889a'],bosque:['#205344','#2c7050'],pradera:['#4d8055','#5d9364'],desierto:['#9b8556','#c4ac72'],colina:['#6d7765','#84947b'],tundra:['#7a9a94','#a9bdb9'],sabana:['#9ea75e','#bdbf71']};
   g.fillStyle='#244337';g.fillRect(0,0,W,H);
   for(let y=0;y<H;y+=16)for(let x=0;x<W;x+=16){
     const kind=this.sim.biomeAt(x+8,y+8),swatch=paint[kind];g.fillStyle=next()<.46?swatch[0]:swatch[1];g.fillRect(x,y,17,17);
     if(kind==='agua'){if(next()<.30){g.fillStyle='#8bced0aa';g.fillRect(x+range(2,11),y+range(2,12),range(2,7),1.6)};continue}
     if(kind==='desierto'){if(next()<.27){g.strokeStyle='#e8cc8655';g.lineWidth=1;g.beginPath();g.moveTo(x+1,y+range(2,14));g.lineTo(x+15,y+range(2,14));g.stroke()}continue}
     if(kind==='colina'){if(next()<.32){g.fillStyle='#ccd1b455';g.beginPath();g.moveTo(x+3,y+13);g.lineTo(x+9,y+3);g.lineTo(x+14,y+13);g.closePath();g.fill()}continue}
     const chance=kind==='bosque'?.29:.07;if(next()<chance){const px=x+range(2,15),py=y+range(2,15),z=range(3,7);g.fillStyle='#092d2888';g.beginPath();g.ellipse(px+2,py+2,z,z*.55,0,0,7);g.fill();g.fillStyle=kind==='bosque'?'#154a3e':'#356e43';g.beginPath();g.arc(px,py,z,0,7);g.fill();g.fillStyle='#7ba66f8f';g.beginPath();g.arc(px-1,py-2,z*.35,0,7);g.fill()}
   }
   for(let y=0;y<H;y+=3){const mid=this.sim.riverX(y),wid=this.sim.riverWidth(y);g.fillStyle='#2b7487';g.fillRect(mid-wid,y,wid*2,3.5);g.fillStyle='#81b9b355';g.fillRect(mid-wid+4,y,1.5,3);g.fillRect(mid+wid-5,y,1.5,3)}
   for(const y of this.sim.fordY()){const x=this.sim.riverX(y),wide=this.sim.riverWidth(y);g.fillStyle='#b7b18f';g.fillRect(x-wide-22,y-30,2*wide+44,60);g.fillStyle='#c5ceab44';for(let j=-25;j<30;j+=10)g.fillRect(x-wide-19,y+j,2*wide+38,2)}
   this.terrain=terrain;
 }
 bound(){const r=this.canvas.getBoundingClientRect(),hw=r.width/2/this.camera.scale,hh=r.height/2/this.camera.scale;this.camera.x=hw>=W/2?W/2:clamp(this.camera.x,hw,W-hw);this.camera.y=hh>=H/2?H/2:clamp(this.camera.y,hh,H-hh)}
 resize(){const dpr=Math.min(window.devicePixelRatio||1,2),b=this.canvas.getBoundingClientRect(),m=this.minimap.getBoundingClientRect();this.canvas.width=Math.max(1,Math.round(b.width*dpr));this.canvas.height=Math.max(1,Math.round(b.height*dpr));this.minimap.width=Math.max(1,Math.round(m.width*dpr));this.minimap.height=Math.max(1,Math.round(m.height*dpr));this.bound();this.draw();this.drawMinimap()}
 point(x,y){const r=this.canvas.getBoundingClientRect();return{x:this.camera.x+(x-r.left-r.width/2)/this.camera.scale,y:this.camera.y+(y-r.top-r.height/2)/this.camera.scale}}
 zoomAt(x,y,n){const anchor=this.point(x,y),r=this.canvas.getBoundingClientRect();this.camera.scale=clamp(n,.2,3.2);this.camera.x=anchor.x-(x-r.left-r.width/2)/this.camera.scale;this.camera.y=anchor.y-(y-r.top-r.height/2)/this.camera.scale;this.bound()}
 zoomCenter(mult){const r=this.canvas.getBoundingClientRect();this.zoomAt(r.left+r.width/2,r.top+r.height/2,this.camera.scale*mult)}
 overview(){const r=this.canvas.getBoundingClientRect();this.camera={x:W/2,y:H/2,scale:clamp(Math.min((r.width-18)/W,(r.height-18)/H),.2,3.2)};this.follow='free';this.bound()}
 centerBoth(){const [a,b]=this.sim.people;this.camera.x=(a.x+b.x)/2;this.camera.y=(a.y+b.y)/2;this.follow='both';this.bound()}
 updateFollow(dt){if(this.follow==='free')return;const [a,b]=this.sim.people;const p=this.follow==='kaelor'?a:this.follow==='ilyra'?b:{x:(a.x+b.x)/2,y:(a.y+b.y)/2};this.camera.x+=(p.x-this.camera.x)*Math.min(1,dt*1.8);this.camera.y+=(p.y-this.camera.y)*Math.min(1,dt*1.8);this.bound()}
 draw(){if(!this.terrain)return;const g=this.ctx,c=this.camera,w=this.canvas.width,h=this.canvas.height,scale=c.scale*this.canvas.width/Math.max(1,this.canvas.clientWidth);g.setTransform(1,0,0,1,0,0);g.fillStyle='#112923';g.fillRect(0,0,w,h);g.setTransform(scale,0,0,scale,w/2-c.x*scale,h/2-c.y*scale);g.drawImage(this.terrain,0,0);
   for(const b of this.sim.bushes){if(b.x<c.x-w/scale/2-40||b.x>c.x+w/scale/2+40||b.y<c.y-h/scale/2-40||b.y>c.y+h/scale/2+40)continue;window.GenesisVisual?.drawBush(g,b)}
   if(this.showDestinations)for(const p of this.sim.people.filter(q=>q.alive!==false)){if(!p.target)continue;
     const points=(p.route||[]).slice(p.routeIndex||0);
     if(!points.length)points.push(p.target);
     g.save();g.setLineDash([7,5]);g.lineWidth=2.5;g.strokeStyle=p.color+'dc';g.beginPath();g.moveTo(p.x,p.y);
     for(const wp of points)g.lineTo(wp.x,wp.y);g.stroke();g.setLineDash([]);
     for(const wp of points.slice(0,-1)){g.fillStyle='#f9fff5';g.beginPath();g.arc(wp.x,wp.y,2.5,0,7);g.fill()}
     g.fillStyle=p.color;g.beginPath();g.arc(p.target.x,p.target.y,6,0,7);g.fill();g.restore();
   }
   for(const p of this.sim.people.filter(q=>q.alive!==false))window.GenesisVisual?.drawPerson(g,p,this.sim.tick);
   g.setTransform(1,0,0,1,0,0);const hour=(this.sim.timeMin%1440)/60;if(hour<6||hour>19){const alpha=hour<6?Math.min(.43,(6-hour)*.11):Math.min(.43,(hour-19)*.11);g.fillStyle=`rgba(1,17,32,${alpha})`;g.fillRect(0,0,w,h)}
 }
 drawMinimap(){const g=this.miniCtx,w=this.minimap.width,h=this.minimap.height;if(!w||!h)return;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);g.drawImage(this.terrain,0,0,w,h);for(const p of this.sim.people.filter(q=>q.alive!==false)){g.beginPath();g.fillStyle=p.color;g.arc(p.x/W*w,p.y/H*h,Math.max(3,w/50),0,Math.PI*2);g.fill();g.strokeStyle='#0b2921';g.lineWidth=1.5;g.stroke()}const r=this.canvas.getBoundingClientRect(),ww=Math.min(W,r.width/this.camera.scale),hh=Math.min(H,r.height/this.camera.scale),x=(this.camera.x-ww/2)/W*w,y=(this.camera.y-hh/2)/H*h;g.lineWidth=2;g.strokeStyle='#fff2c1';g.fillStyle='#e9fcde18';g.fillRect(x,y,ww/W*w,hh/H*h);g.strokeRect(x,y,ww/W*w,hh/H*h)}
}
root.GenesisView=GenesisView;
})(typeof globalThis!=='undefined'?globalThis:this);

