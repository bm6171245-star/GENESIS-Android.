
/* GÉNESIS 009 · Motor autónomo, navegación y control temporal. */
(function (root) {
'use strict';
const W=1440,H=960,DT=1/30,GRID=24,GW=Math.ceil(W/GRID),GH=Math.ceil(H/GRID);
const DEFAULT_PERSON=Object.freeze({foodAt:67,waterAt:68,restAt:44,metabolism:100,recovery:100});
const DEFAULT_WORLD=Object.freeze({growth:100});
const NAMES=['Kaelor','Ilyra'];
const PERSON_LIMITS={foodAt:[10,95],waterAt:[10,95],restAt:[10,95],metabolism:[50,200],recovery:[50,200]};
const PRESETS=['valle','bosque','arido'];
function checked(candidate,defaults,limits){
 if(!candidate||typeof candidate!=='object'||Array.isArray(candidate))throw Error('Leyes inválidas');
 const out={};for(const key of Object.keys(defaults)){const n=candidate[key];if(typeof n!=='number'||!Number.isInteger(n)||n<limits[key][0]||n>limits[key][1])throw Error('Valor inválido: '+key);out[key]=n}return out;
}
function checkPerson(r){return checked(r,DEFAULT_PERSON,PERSON_LIMITS)}
function checkWorld(r){return checked(r,DEFAULT_WORLD,{growth:[20,300]})}
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
class GenesisEngine {
  constructor(seed=267013){this.manualName=null;this.manualVector={x:0,y:0};this.rules={...DEFAULT_WORLD};this.personRules={Kaelor:{...DEFAULT_PERSON},Ilyra:{...DEFAULT_PERSON}};this.terrainPreset='valle';this.reset(seed)}
  next(){this.rngState=(Math.imul(1664525,this.rngState)+1013904223)>>>0;return this.rngState/4294967296}
  rand(a,b){return a+(b-a)*this.next()}
  riverX(y){return W*.57+Math.sin(y*.006)*87+Math.sin(y*.014)*20}
  riverWidth(y){return 38+11*Math.sin(y*.009+1)}
  // Vados: zonas poco profundas y transitables a ambos lados del río.
  fordY(){return [250,710]}
  isFord(x,y){return this.fordY().some(f=>Math.abs(y-f)<38)&&Math.abs(x-this.riverX(y))<=this.riverWidth(y)+18}
  water(x,y){return Math.abs(x-this.riverX(y))<this.riverWidth(y)&&!this.isFord(x,y)}
  riverWater(x,y){return Math.abs(x-this.riverX(y))<this.riverWidth(y)}
  biomeAt(x,y){
    if(this.water(x,y))return 'agua';
    const phase=(this.seed%1009)/1009*6.28318530718;
    const altitude=.53*Math.sin(x*.008+phase)+.36*Math.cos(y*.012-phase)+.19*Math.sin((x+y)*.017);
    const humidity=.51*Math.sin(x*.004+phase*2)+.31*Math.cos(y*.007+phase)+.18*Math.cos((x-y)*.012);
    if(altitude>.82)return 'colina';
    const bias=this.terrainPreset==='bosque'?.38:this.terrainPreset==='arido'?-.43:0;
    if(humidity+bias<-.30)return 'desierto';
    if(humidity+bias>.28)return 'bosque';
    return 'pradera';
  }
  setPersonRules(name,candidate){if(!NAMES.includes(name))throw Error('Habitante desconocido');this.personRules[name]=checkPerson(candidate);const p=this.people.find(x=>x.name===name);if(p){p.target=null;p.route=[];p.routeIndex=0;p.stay=0;p.decision=0;p.lastAction=''}this.note('El creador cambió las leyes de '+name+'.')}
  setWorldRules(candidate){this.rules=checkWorld(candidate);this.note('El creador cambió la ley de la naturaleza.')}

  setTerrainPreset(preset){if(!PRESETS.includes(preset))throw Error('Perfil de terreno no reconocido');this.terrainPreset=preset;}

  walkable(x,y){return x>15&&y>15&&x<W-15&&y<H-15&&!this.water(x,y)}
  land(x,y){if(this.walkable(x,y))return{x,y};for(let r=10;r<220;r+=10){for(let a=0;a<6.3;a+=.28){const xx=x+Math.cos(a)*r,yy=y+Math.sin(a)*r;if(this.walkable(xx,yy))return{x:xx,y:yy}}}return{x:W*.3,y:H*.5}}
  addBush(x,y){if(this.bushes.length>=3000)return false;const p=this.land(x,y);if(this.bushes.some(b=>Math.hypot(b.x-p.x,b.y-p.y)<12))return false;this.bushes.push({id:++this.bushSeq,x:p.x,y:p.y,fruit:this.rand(2,5),max:5});return true}
  newPerson(name,color,x,y){const p=this.land(x,y);return{name,color,x:p.x,y:p.y,hunger:73,thirst:63,energy:88,vitality:100,riskLevel:0,act:'Explorando',target:null,stay:0,decision:0,lastAction:'',wander:0,goalReason:'Aún no ha elegido destino',decisionsMade:0,goalFailures:0,route:[],routeIndex:0,routeDistance:0}}
  dateText(){const d=Math.floor(this.timeMin/1440)+1,m=Math.floor(this.timeMin%1440);return {d,txt:`${String(Math.floor(m/60)).padStart(2,'0')}:${String(Math.floor(m%60)).padStart(2,'0')}`}}
  note(msg){const t=this.dateText();this.logs.unshift({t:`D${t.d} ${t.txt}`,msg});this.logs=this.logs.slice(0,24)}
  reset(seed,preset=this.terrainPreset){this.setTerrainPreset(preset);this.seed=(Number(seed)>>>0)||267013;this.rngState=this.seed;this.bushes=[];this.bushSeq=0;this.people=[];this.timeMin=420;this.tick=0;this.logs=[];this.grid=null;
    for(let i=0;i<230;i++){const p=this.land(this.rand(40,W-40),this.rand(40,H-40)),b=this.biomeAt(p.x,p.y),odds=b==='bosque'?.66:b==='pradera'?.35:b==='colina'?.12:.025;if(this.next()<odds)this.addBush(p.x,p.y)}
    const x=this.riverX(H*.49),a=this.land(x-112,H*.49-30),b=this.land(x-125,H*.49+35);
    this.people=[this.newPerson('Kaelor','#a5f6dc',a.x,a.y),this.newPerson('Ilyra','#f5d69c',b.x,b.y)];this.addBush(a.x-45,a.y-20);this.addBush(b.x-65,b.y+20);
    this.note('Comienza el primer día en el Valle del Origen.');this.note('Kaelor e Ilyra aparecen junto al río.');
  }
  setManualName(name,keepRoute=false){this.manualName=NAMES.includes(name)?name:null;this.manualVector={x:0,y:0};if(this.manualName){const p=this.people.find(p=>p.name===this.manualName);if(p&&!keepRoute){p.target=null;p.route=[];p.routeIndex=0;p.stay=0;p.decision=0;p.act='Bajo tu control';}}}
  setManualVector(dx,dy){this.manualVector={x:clamp(dx,-1,1),y:clamp(dy,-1,1)}}
  directPersonTo(name,point){const p=this.people.find(p=>p.name===name);if(!p||this.manualName!==name||!this.walkable(point.x,point.y))return false;
   const path=this.findRoute(p,point);if(!path)return false;
   p.target={x:point.x,y:point.y};p.route=path.points.map(z=>({x:z.x,y:z.y}));p.routeIndex=0;p.routeDistance=path.distance;p.act='Caminando a destino';p.goalReason='Orden dada por el jugador';p.stay=0;return true;
  }
  // Una ruta directa se usa cuando está libre; si no, búsqueda A* en una malla de 24 unidades.
  side(x,y){return x<this.riverX(y)?-1:1}
  directReach(a,b){
    if(!b||!this.walkable(a.x,a.y)||!this.walkable(b.x,b.y))return false;
    const dist=Math.hypot(b.x-a.x,b.y-a.y),checks=Math.max(1,Math.ceil(dist/6));
    for(let i=1;i<=checks;i++){const t=i/checks;if(!this.walkable(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t))return false}
    return true;
  }
  navGrid(){
    if(this.grid)return this.grid;
    const grid=new Uint8Array(GW*GH);
    for(let cy=0;cy<GH;cy++)for(let cx=0;cx<GW;cx++){
      const x=(cx+.5)*GRID,y=(cy+.5)*GRID;
      // Los centros de celda deben estar en zona transitable.
      grid[cy*GW+cx]=this.walkable(x,y)?1:0;
    }
    this.grid=grid;return grid;
  }
  // El algoritmo explora solamente los nodos que pueden mejorar la distancia.
  findRoute(a,b){
    if(!b||!this.walkable(a.x,a.y)||!this.walkable(b.x,b.y))return null;
    const dist=Math.hypot(b.x-a.x,b.y-a.y);
    if(this.directReach(a,b))return {points:[{x:b.x,y:b.y}],distance:dist};
    const pass=this.navGrid(),size=GW*GH;
    const loc=(x,y)=>{const cx=clamp(Math.floor(x/GRID),0,GW-1),cy=clamp(Math.floor(y/GRID),0,GH-1);return cy*GW+cx};
    const centers=i=>({x:((i%GW)+.5)*GRID,y:(Math.floor(i/GW)+.5)*GRID});
    const closest=(point)=>{
      const ix=clamp(Math.floor(point.x/GRID),0,GW-1),iy=clamp(Math.floor(point.y/GRID),0,GH-1);
      let best=-1,ds=Infinity;
      for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){
        const xx=ix+dx,yy=iy+dy;if(xx<0||yy<0||xx>=GW||yy>=GH)continue;
        const i=yy*GW+xx;if(!pass[i])continue;
        const c=centers(i),d=Math.hypot(c.x-point.x,c.y-point.y);
        if(d<ds&&this.directReach(point,c)){best=i;ds=d}
      }
      return best;
    };
    const start=closest(a),goal=closest(b);if(start<0||goal<0)return null;
    const g=new Float64Array(size).fill(Infinity),parent=new Int32Array(size).fill(-1),closed=new Uint8Array(size);
    const heap=[];
    function push(i,score){let k=heap.length;heap.push({i,score});while(k){let parentIndex=(k-1)>>1;if(heap[parentIndex].score<=score)break;heap[k]=heap[parentIndex];k=parentIndex}heap[k]={i,score}}
    function pop(){const top=heap[0],end=heap.pop();if(!heap.length)return top;let k=0;while(2*k+1<heap.length){let c=2*k+1;if(c+1<heap.length&&heap[c+1].score<heap[c].score)c++;if(heap[c].score>=end.score)break;heap[k]=heap[c];k=c}heap[k]=end;return top}
    const goalPt=centers(goal);g[start]=0;push(start,dist);
    const steps=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]];
    let visits=0;
    while(heap.length&&visits<size){const node=pop(),i=node.i;if(closed[i])continue;closed[i]=1;visits++;if(i===goal)break;
      const cx=i%GW,cy=(i/GW)|0,here=centers(i);
      for(const [dx,dy] of steps){const nx=cx+dx,ny=cy+dy;if(nx<0||ny<0||nx>=GW||ny>=GH)continue;
        const j=ny*GW+nx;if(!pass[j]||closed[j])continue;
        if(dx&&dy&&(!pass[cy*GW+nx]||!pass[ny*GW+cx]))continue;
        const there=centers(j);if(!this.directReach(here,there))continue;
        const nd=g[i]+Math.hypot(dx,dy)*GRID;if(nd>=g[j])continue;
        g[j]=nd;parent[j]=i;push(j,nd+Math.hypot(there.x-goalPt.x,there.y-goalPt.y));
      }
    }
    if(!Number.isFinite(g[goal]))return null;
    const ids=[];let at=goal;for(let n=0;at!==-1&&n<size;n++,at=parent[at]){ids.push(at);if(at===start)break}
    if(ids.at(-1)!==start)return null;ids.reverse();
    let points=ids.slice(1).map(centers);points.push({x:b.x,y:b.y});
    // Se eliminan nodos innecesarios si el segmento recto no atraviesa obstáculos.
    const simplified=[];let cursor={x:a.x,y:a.y};
    while(points.length){let furthest=0;for(let k=1;k<points.length;k++){if(this.directReach(cursor,points[k]))furthest=k;else break}
      simplified.push(points[furthest]);cursor=points[furthest];points=points.slice(furthest+1);
    }
    let traveled=0,prev=a;for(const point of simplified){traveled+=Math.hypot(point.x-prev.x,point.y-prev.y);prev=point}
    return {points:simplified,distance:traveled};
  }
  selectRiver(p){
    const sign=this.side(p.x,p.y);let best=null,dist=Infinity;
    for(let delta=-240;delta<=240;delta+=24){const y=clamp(p.y+delta,22,H-22),x=this.riverX(y)+sign*(this.riverWidth(y)+19),pos={x,y};
      if(this.isFord(x,y))continue;
      const d=Math.hypot(pos.x-p.x,pos.y-p.y);if(d<dist&&this.directReach(p,pos)){best=pos;dist=d}}
    return best?{pos:best,distance:dist,route:{points:[best],distance:dist}}:null;
  }
  selectFood(p){
    // Se examinan los doce arbustos con fruta más cercanos, eligiendo por longitud de ruta.
    const options=this.bushes.filter(b=>b.fruit>=1).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y)).slice(0,12);
    let best=null,dist=Infinity,foundRoute=null;
    for(const b of options){const pos={x:b.x,y:b.y},route=this.findRoute(p,pos);if(!route||route.distance>=dist)continue;
      best=b;dist=route.distance;foundRoute=route;
    }
    return best?{pos:{x:best.x,y:best.y,bushId:best.id},distance:dist,route:foundRoute}:null;
  }
  priority(level,limit,travel){
    if(level>=limit)return -Infinity;
    const urgency=(limit-level)/Math.max(limit,1),critical=clamp((32-level)/32,0,1);
    return .6+urgency*2.8+critical*1.45-travel/1250;
  }
  choose(p){
    const law=this.personRules[p.name],candidates=[];
    if(p.thirst<law.waterAt){const river=this.selectRiver(p);if(river)candidates.push({act:'Buscando agua',target:river.pos,route:river.route,score:this.priority(p.thirst,law.waterAt,river.distance)+.06,info:`Sed ${Math.round(p.thirst)}% · río a ${Math.round(river.distance)} m`})}
    if(p.hunger<law.foodAt){const food=this.selectFood(p);if(food)candidates.push({act:'Buscando comida',target:food.pos,route:food.route,score:this.priority(p.hunger,law.foodAt,food.distance),info:`Comida ${Math.round(p.hunger)}% · ruta de ${Math.round(food.distance)} m`})}
    if(p.energy<law.restAt)candidates.push({act:'Descansando',target:null,score:this.priority(p.energy,law.restAt,0),info:`Energía ${Math.round(p.energy)}% · descanso necesario`});
    candidates.sort((a,b)=>b.score-a.score);
    let plan=candidates[0];
    if(!plan){
      // La exploración evita elegir destinos al otro lado del río o a través del agua.
      for(let i=0;i<12;i++){const x=clamp(p.x+this.rand(-240,240),20,W-20),y=clamp(p.y+this.rand(-240,240),20,H-20);const pos={x,y};if(Math.hypot(x-p.x)<45)continue;const route=this.findRoute(p,pos);if(route){plan={act:'Explorando',target:pos,route,score:0,info:'Necesidades cubiertas · explorando rutas transitables'};break}}
      if(!plan)plan={act:'Observando',target:null,score:0,info:'Sin lugar cercano accesible; vuelve a evaluar'};
    }
    const changed=p.act!==plan.act || !p.target!==!plan.target || (p.target&&plan.target&&Math.hypot(p.target.x-plan.target.x,p.target.y-plan.target.y)>18);
    p.act=plan.act;p.target=plan.target;p.route=plan.route?.points?.map(x=>({x:x.x,y:x.y}))||[];p.routeIndex=0;p.routeDistance=plan.route?.distance||0;p.goalReason=plan.info;p.decision=plan.target?7:2.5;p.decisionsMade=(p.decisionsMade||0)+1;
    if(plan.act==='Descansando')p.stay=4;
    else if(plan.act==='Observando')p.stay=1.4;
    if(changed&&plan.act!=='Explorando'&&plan.act!=='Observando'&&p.lastGoal!==plan.act){this.note(`${p.name}: ${plan.info}.`)}
    p.lastGoal=plan.act;
  }
  complete(p){
    if(p.act==='Buscando agua'){p.act='Bebiendo agua';p.thirst=clamp(p.thirst+48,0,100);p.stay=2.1;if(p.lastAction!=='agua'){this.note(`${p.name} encontró agua en el río.`);p.lastAction='agua'}}
    else if(p.act==='Buscando comida'){const b=p.target&&this.bushes.find(b=>b.id===p.target.bushId);if(b&&b.fruit>=1){b.fruit--;p.hunger=clamp(p.hunger+38,0,100);p.act='Comiendo frutos';p.stay=1.8;if(p.lastAction!=='comida'){this.note(`${p.name} recogió frutos silvestres.`);p.lastAction='comida'}}else{p.act='Observando';p.stay=.1}}
    else{p.act='Observando';p.stay=.8}
    p.target=null;p.route=[];p.routeIndex=0;p.routeDistance=0;p.decision=0;
  }
  step(dt=DT){if(!finite(dt,0,.5))throw Error('Paso temporal no válido');this.tick++;const previous=Math.floor(this.timeMin/1440);this.timeMin+=dt*15;const day=Math.floor(this.timeMin/1440);if(day>previous)this.note(`Comienza el día ${day+1}.`);
    for(const b of this.bushes)if(b.fruit<5){const biome=this.biomeAt(b.x,b.y),factor=biome==='desierto'?.20:biome==='bosque'?1.5:biome==='colina'?.65:1;b.fruit=Math.min(5,b.fruit+dt*.008*this.rules.growth/100*factor);}
    for(const p of this.people){const law=this.personRules[p.name];
      p.hunger=clamp(p.hunger-dt*.27*law.metabolism/100,0,100);
      p.thirst=clamp(p.thirst-dt*.48*law.metabolism/100,0,100);
      p.energy=clamp(p.energy-dt*.23*law.metabolism/100,0,100);
      const shortage=Number(p.hunger<15)+Number(p.thirst<15)+Number(p.energy<10);
      const recovery=shortage===0&&p.hunger>42&&p.thirst>42&&p.energy>30;
      p.vitality=clamp(p.vitality+(shortage?-dt*.85*shortage:recovery?dt*.4:0),1,100);
      const danger=p.vitality<35?2:shortage?1:0;
      if(danger>p.riskLevel)this.note(p.name+' necesita recursos: su estado ha empeorado.');
      if(danger===0&&p.riskLevel>0)this.note(p.name+' recuperó su estabilidad.');
      p.riskLevel=danger;
      if(p.name===this.manualName){
        const input=this.manualVector,mag=Math.hypot(input.x,input.y),manual=mag>.01;
        if(manual){p.target=null;p.route=[];p.routeIndex=0;p.act='Bajo tu control';p.goalReason='Movimiento directo del jugador';}
        if(manual){const speed=(p.energy<20||p.vitality<35?28:65)*dt,dx=input.x/mag*speed,dy=input.y/mag*speed;
          const nx=p.x+dx,ny=p.y+dy;if(this.walkable(nx,ny)){p.x=nx;p.y=ny}
          else if(this.walkable(nx,p.y)){p.x=nx}
          else if(this.walkable(p.x,ny)){p.y=ny}
        }else if(p.target){let waypoint=p.route?.[p.routeIndex]||p.target;
          let vx=waypoint.x-p.x,vy=waypoint.y-p.y,d=Math.hypot(vx,vy);
          if(d<8){if(p.routeIndex<(p.route?.length||0)-1){p.routeIndex++;waypoint=p.route[p.routeIndex];vx=waypoint.x-p.x;vy=waypoint.y-p.y;d=Math.hypot(vx,vy)}else{p.target=null;p.route=[];p.routeIndex=0;p.act='Destino alcanzado';p.goalReason='Ruta completada';continue}}
          if(d>0){const step=Math.min(d,(p.energy<20?25:55)*dt),nx=p.x+vx/d*step,ny=p.y+vy/d*step;
             if(this.walkable(nx,ny)){p.x=nx;p.y=ny}else{p.target=null;p.route=[];p.routeIndex=0;p.act='Camino bloqueado';p.goalReason='Ruta no transitable'}}
        }
        continue;
      }
      if(p.stay>0){p.stay-=dt;if(p.act==='Descansando')p.energy=clamp(p.energy+dt*10*law.recovery/100,0,100);if(p.stay<=0){p.decision=0;p.lastAction=''}continue}
      p.decision-=dt;
      const exhaustedFruit=p.act==='Buscando comida'&&(!p.target?.bushId||!(this.bushes.find(b=>b.id===p.target.bushId)?.fruit>=1));
      const emergencyThirst=p.act!=='Buscando agua'&&p.thirst<Math.min(16,law.waterAt);
      if(!p.target||exhaustedFruit||emergencyThirst||p.decision<=0){
        if(p.target&&!exhaustedFruit&&!emergencyThirst&&((p.route?.length>p.routeIndex)||this.directReach(p,p.target)))p.decision=7;
        else this.choose(p);
      }
      if(!p.target)continue;
      // Avanzamos por puntos intermedios hasta alcanzar el destino definitivo.
      let waypoint=p.route?.[p.routeIndex]||p.target;
      let vx=waypoint.x-p.x,vy=waypoint.y-p.y,d=Math.hypot(vx,vy);
      if(d<9){if(p.routeIndex<(p.route?.length||0)-1){p.routeIndex++;waypoint=p.route[p.routeIndex];vx=waypoint.x-p.x;vy=waypoint.y-p.y;d=Math.hypot(vx,vy)}else{this.complete(p);continue}}
      const biome=this.biomeAt(p.x,p.y),terrainPace=biome==='colina'?.65:biome==='desierto'?.84:1;const pace=(p.energy<20||p.vitality<35?26:46)*dt*terrainPace,nx=p.x+vx/d*Math.min(d,pace),ny=p.y+vy/d*Math.min(d,pace);
      if(this.walkable(nx,ny)){p.x=nx;p.y=ny}else{p.goalFailures=(p.goalFailures||0)+1;p.target=null;p.route=[];p.routeIndex=0;p.decision=0;p.goalReason='Tramo bloqueado, volverá a calcular la ruta';}

    }
  }
  snapshot(){return{version:10,project:'GENESIS',release:'030',rules:{...this.rules},personRules:{Kaelor:{...this.personRules.Kaelor},Ilyra:{...this.personRules.Ilyra}},terrainPreset:this.terrainPreset,seed:this.seed,rngState:this.rngState,bushes:this.bushes,people:this.people,timeMin:this.timeMin,logs:this.logs,tick:this.tick}}
  load(raw){
    if(!raw||![3,4,5,6,7,8,9,10].includes(raw.version)||!finite(raw.seed,0,4294967295)||!finite(raw.timeMin,0,1e10)||!Array.isArray(raw.people)||raw.people.length!==2||!Array.isArray(raw.bushes)||raw.bushes.length>3000)throw Error('Archivo de mundo incompatible');
    const names=new Set(raw.people.map(p=>p&&p.name));if(names.size!==2||!names.has('Kaelor')||!names.has('Ilyra'))throw Error('Faltan los habitantes originales');
    for(const p of raw.people){if(!p||!finite(p.x,0,W)||!finite(p.y,0,H)||!finite(p.hunger,0,100)||!finite(p.thirst,0,100)||!finite(p.energy,0,100))throw Error('Datos de habitante no válidos')}
    for(const b of raw.bushes){if(!b||!finite(b.x,0,W)||!finite(b.y,0,H)||!finite(b.fruit,0,5))throw Error('Datos de arbusto no válidos')}
    let nextRules,nextPersonRules;
    if(raw.version>=7){nextRules=checkWorld(raw.rules);if(!raw.personRules)throw Error('Faltan las reglas de habitantes');nextPersonRules={Kaelor:checkPerson(raw.personRules.Kaelor),Ilyra:checkPerson(raw.personRules.Ilyra)}}
    else if(raw.version===6){const rr=raw.rules;if(!rr)throw Error('Faltan leyes antiguas');const prior=checkPerson({foodAt:rr.foodAt,waterAt:rr.waterAt,restAt:rr.restAt,metabolism:rr.metabolism,recovery:100});nextRules=checkWorld({growth:rr.growth});nextPersonRules={Kaelor:{...prior},Ilyra:{...prior}}}
    else {nextRules={...DEFAULT_WORLD};nextPersonRules={Kaelor:{...DEFAULT_PERSON},Ilyra:{...DEFAULT_PERSON}}}
    const nextTerrain=raw.version>=6?raw.terrainPreset:'valle';
    if(!PRESETS.includes(nextTerrain))throw Error('Perfil de terreno no válido');
    // Verificamos primero, después sustituimos el mundo para no perderlo ante una importación inválida.
    const bs=raw.bushes.map((b,i)=>({id:finite(b.id,1,10000000)?Math.floor(b.id):i+1,x:b.x,y:b.y,fruit:b.fruit,max:5}));
    const ps=raw.people.map(p=>({name:p.name,color:p.name==='Kaelor'?'#a5f6dc':'#f5d69c',x:p.x,y:p.y,hunger:p.hunger,thirst:p.thirst,energy:p.energy,vitality:raw.version>=7&&finite(p.vitality,1,100)?p.vitality:100,riskLevel:raw.version>=7&&Number.isInteger(p.riskLevel)&&p.riskLevel>=0&&p.riskLevel<=2?p.riskLevel:0,act:typeof p.act==='string'&&p.act.length<=40?p.act:'Explorando',target:p.target&&finite(p.target.x,0,W)&&finite(p.target.y,0,H)?{x:p.target.x,y:p.target.y,...('bushId' in p.target?{bushId:p.target.bushId}:{})}:null,stay:finite(p.stay,-60,60)?p.stay:0,decision:finite(p.decision,0,60)?p.decision:0,lastAction:['agua','comida'].includes(p.lastAction)?p.lastAction:'',wander:0,goalReason:raw.version>=8&&typeof p.goalReason==='string'?p.goalReason.slice(0,120):'Destino heredado de partida anterior',decisionsMade:raw.version>=8&&finite(p.decisionsMade,0,1e9)?Math.floor(p.decisionsMade):0,goalFailures:raw.version>=8&&finite(p.goalFailures,0,1e9)?Math.floor(p.goalFailures):0,lastGoal:raw.version>=8&&typeof p.lastGoal==='string'?p.lastGoal.slice(0,40):'',
      route:raw.version>=9&&Array.isArray(p.route)&&p.route.length<=500?p.route.filter(z=>z&&finite(z.x,0,W)&&finite(z.y,0,H)).map(z=>({x:z.x,y:z.y})):[],
      routeIndex:raw.version>=9&&Number.isInteger(p.routeIndex)&&p.routeIndex>=0&&p.routeIndex<=(p.route?.length||0)?p.routeIndex:0,
      routeDistance:raw.version>=9&&finite(p.routeDistance,0,1e6)?p.routeDistance:0}));
    // La versión 001 guardaba una copia del arbusto en el destino.
    for(let i=0;i<ps.length;i++){const prior=raw.people[i].target;if(prior?.bush&&!ps[i].target?.bushId){const b=bs.find(b=>Math.hypot(b.x-prior.bush.x,b.y-prior.bush.y)<.1);if(b&&ps[i].target)ps[i].target.bushId=b.id}}
    this.rules=nextRules;this.personRules=nextPersonRules;this.terrainPreset=nextTerrain;this.grid=null;this.seed=raw.seed>>>0;this.rngState=Number.isFinite(raw.rngState)?raw.rngState>>>0:this.seed;this.bushes=bs;this.bushSeq=Math.max(0,...bs.map(b=>b.id));this.people=ps;for(const p of this.people){
      // En partidas de versiones anteriores recalculamos rutas con el motor 007.
      if(raw.version<9){p.target=null;p.route=[];p.routeIndex=0;p.decision=0;p.stay=0;}
    }this.timeMin=raw.timeMin;this.tick=finite(raw.tick,0,1e11)?Math.floor(raw.tick):0;
    this.logs=Array.isArray(raw.logs)?raw.logs.filter(e=>e&&typeof e.t==='string'&&typeof e.msg==='string').slice(0,24).map(e=>({t:e.t.slice(0,24),msg:e.msg.slice(0,150)})):[];
  }
}
const API={GenesisEngine,DT,W,H,clamp,DEFAULT_PERSON,DEFAULT_WORLD,PRESETS};
root.GenesisCore=API;
if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof globalThis!=='undefined'?globalThis:this);

