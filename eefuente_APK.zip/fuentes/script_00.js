
(function(){
 'use strict';
 const main=document.querySelector('main');
 const q=(sel)=>main.querySelector(sel);
 const scene=q('.scene'),head=q('.head'),metrics=q('.metrics'),tools=q('.tools');
 if(!main||!scene||!head||!metrics||!tools)return;
 document.body.classList.add('immersive');
 const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text)e.textContent=text;return e};
 const top=el('div','gameTopbar');top.id='gameTopbar';
 top.append(head,metrics);
 const quick=el('div','topControls');
 for(const id of ['pause','speed','zoomOut','zoomIn']){const b=document.getElementById(id);if(b)quick.append(b)}
 top.append(quick);main.append(top);
 const dock=el('nav','');dock.id='gameDock';dock.setAttribute('aria-label','Accesos del videojuego');
 const shade=el('div','');shade.id='gameShade';shade.hidden=true;
 const drawer=el('aside','');drawer.id='gameDrawer';drawer.hidden=true;drawer.setAttribute('role','dialog');drawer.setAttribute('aria-label','Herramientas de GÉNESIS');drawer.setAttribute('aria-modal','false');
 const heading=el('div','drawerTitle');const h=el('div','');const name=el('strong','', 'Herramientas');name.id='drawerHeading';h.append(name,el('small','','El mundo sigue visible detrás del panel'));heading.append(h);
 const close=el('button','', '×');close.id='drawerClose';close.type='button';close.setAttribute('aria-label','Cerrar herramientas');heading.append(close);
 const tabs=el('div','drawerTabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Categorías');
 const scroll=el('div','drawerScroll');drawer.append(heading,tabs,scroll);
 const pageSpecs=[
  {id:'aldea',title:'Civilización',items:['#civLab']},
  {id:'habitantes',title:'Habitantes',items:['.panels','#peopleLab','#mindLab','.decisionPanel']},
  {id:'naturaleza',title:'Naturaleza',items:['#naturePanel','.terrainPanel']},
  {id:'leyes',title:'Leyes',items:['#lawEditor']},
  {id:'tiempo',title:'Tiempo',items:['#timePanel']},
  {id:'mundos',title:'Mundos',items:['#worldArchive','.meta']},
  {id:'controles',title:'Controles',items:['#modePanel','.tools','.cameraBadge','.cameraBadge','.journal']},
  {id:'ayuda',title:'Información',items:['.intro','.footnote']}
 ];
 const pages={};const buttons={};
 for(const spec of pageSpecs){
  const page=el('div','drawerPage');page.dataset.page=spec.id;page.hidden=true;
  for(const selector of spec.items){const node=q(selector);if(node)page.append(node)}
  scroll.append(page);pages[spec.id]=page;
  const btn=el('button','',spec.title);btn.type='button';btn.dataset.tab=spec.id;btn.setAttribute('role','tab');btn.setAttribute('aria-selected','false');btn.onclick=()=>open(spec.id);
  tabs.append(btn);buttons[spec.id]=btn;
 }
 const notice=document.getElementById('notice');if(notice){const holder=el('div','');holder.id='gameNotice';holder.append(notice);main.append(holder)}
 main.append(shade,drawer,dock);
 let active=null;
 function open(id){
  if(!pages[id])id='controles';
  for(const key of Object.keys(pages)){const is=key===id;pages[key].hidden=!is;buttons[key].classList.toggle('active',is);buttons[key].setAttribute('aria-selected',String(is))}
  active=id;name.textContent=buttons[id].textContent;shade.hidden=false;drawer.hidden=false;
  scroll.scrollTop=0;tabs.querySelector('.active')?.scrollIntoView({inline:'nearest',block:'nearest'});
  close.focus({preventScroll:true});
 }
 function shut(){drawer.hidden=true;shade.hidden=true;active=null;}
 window.GenesisUI050={open,close:shut,active:()=>active,pages:Object.keys(pages),immersive:true};
 close.onclick=shut;shade.onclick=shut;
 document.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&!drawer.hidden){ev.preventDefault();shut()}});
 // Bottom dock uses the original mode controls: no new gameplay logic or duplicate listeners.
 const actions=[
  ['observer','◉','Observar',()=>document.getElementById('modeObserver')?.click()],
  ['creator','✦','Crear',()=>document.getElementById('modeCreator')?.click()],
  ['character','◆','Personaje',()=>document.getElementById('modeCharacter')?.click()],
  ['aldea','⌂','Aldea',()=>open('aldea')],
  ['habitantes','♟','Habitantes',()=>open('habitantes')],
  ['menu','☰','Menú',()=>open('controles')]
 ];
 const dockBtns={};
 for(const [id,glyph,title,callback] of actions){const btn=el('button','');btn.type='button';btn.dataset.dock=id;btn.setAttribute('aria-label',title);
  btn.append(el('span','glyph',glyph),el('span','',title));btn.onclick=()=>{callback();updateDock()};dock.append(btn);dockBtns[id]=btn;}
 function updateDock(){const mode=document.body.dataset.gameMode||'observer';for(const id of ['observer','creator','character']){dockBtns[id].classList.toggle('selected',mode===id);dockBtns[id].setAttribute('aria-pressed',String(mode===id))}}
 new MutationObserver(updateDock).observe(document.body,{attributes:true,attributeFilter:['data-game-mode']});updateDock();
 // Old scroll-only shortcut must open the right sheet in the new non-scrolling layout.
 const shortcut=document.getElementById('creatorLaws');
 if(shortcut)shortcut.addEventListener('click',event=>{event.preventDefault();event.stopImmediatePropagation();open('leyes')},true);
 const observer=new ResizeObserver(()=>{window.dispatchEvent(new Event('resize'))});observer.observe(scene);
})();
