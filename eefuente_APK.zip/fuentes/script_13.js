
/* UI de habitantes 021–030; usa el motor ya existente. */
(function(){'use strict';const STAGE=30,api=window.GenesisNatureAccess;if(!api)return;
const sim=api.sim,view=api.view,$=id=>document.getElementById(id),lab=$('peopleLab');
for(const el of lab.querySelectorAll('[data-stage]'))if(Number(el.dataset.stage)>STAGE)el.hidden=true;
let selected='Kaelor',stamp='';
const msg=m=>{$('labStatus').textContent=m;api.note(m)};
function refresh(force=false){const info=sim.populationStats();$('labLiving').textContent=info.living;$('labNew').textContent=info.descendants;$('labGenerations').textContent=info.generations;$('labAverage').textContent=info.averageAge;
 const ids=sim.people.map(p=>p.name).join('|');if(force||ids!==stamp){const old=$('labSelect').value||selected;const s=$('labSelect');s.replaceChildren();for(const p of sim.people){const o=document.createElement('option');o.value=p.name;o.textContent=p.name+(p.alive?'':' (histórico)');s.append(o)}s.value=sim.people.some(p=>p.name===old)?old:'Kaelor';stamp=ids}
 const p=sim.people.find(p=>p.name===$('labSelect').value)||sim.people[0];if(!p)return;selected=p.name;const ancestry=p.parents?.length?p.parents.map(id=>sim.people.find(x=>x.id===id)?.name||('ID '+id)).join(' y '):'Sin ascendencia registrada';
 $('labBio').textContent=`${p.name} · ${p.alive?'Presente':'Registro histórico'}\nEdad ${sim.ageOf(p)} años · Generación ${p.generation||0} · Familia ${p.family||'origen'} · Ascendencia: ${ancestry}\nVitalidad ${Math.round(p.vitality)}% · Resistencia ${p.resilience}% · Estado de salud: ${p.illness?('enfermedad '+Math.round(p.illness)+'% '):''}${p.injury?('lesión '+Math.round(p.injury)+'%'):'sin incidencias registradas'}\nNecesidades: comida ${Math.round(p.hunger)} / agua ${Math.round(p.thirst)} / energía ${Math.round(p.energy)} · Decisión: ${p.act}`.replaceAll('\\n','\n');
 $('labMortality').checked=sim.community.mortality;$('labAging').checked=sim.community.aging;$('labIllness').checked=sim.community.illness;$('labBirths').checked=sim.community.births;
 if(document.activeElement!==$('labResilience'))$('labResilience').value=p.resilience;
 if(document.activeElement!==$('labCapacity'))$('labCapacity').value=sim.community.maxPopulation;
 if(document.activeElement!==$('labBirthRate'))$('labBirthRate').value=sim.community.yearlyBirthRate;
}
function doIt(fn){try{const s=fn();api.persist(true);refresh(true);view.draw();view.drawMinimap();msg(s||'Cambios aplicados')}catch(e){msg('No se pudo realizar: '+e.message)}}
$('labSelect').onchange=()=>refresh(true);$('labUpdate').onclick=()=>refresh(true);
$('labMortality').onchange=()=>doIt(()=>{sim.setCommunityOption('mortality',$('labMortality').checked);return 'Mortalidad: '+(sim.community.mortality?'activada':'desactivada')});
$('labAging').onchange=()=>doIt(()=>{sim.setCommunityOption('aging',$('labAging').checked);return 'Envejecimiento '+(sim.community.aging?'activo':'pausado')});
$('labOneYear').onclick=()=>doIt(()=>{const s=sim.advanceYears(1);return `Avance aproximado: 1 año. Población ${s.living}.`});
$('labFiveYears').onclick=()=>doIt(()=>{const s=sim.advanceYears(5);return `Avance aproximado: 5 años. Población ${s.living}.`});
$('labSetResilience').onclick=()=>doIt(()=>{const n=Number($('labResilience').value);sim.setResilience(selected,n);return selected+': resistencia '+n+'%'});
$('labIllness').onchange=()=>doIt(()=>{sim.setCommunityOption('illness',$('labIllness').checked);return 'Salud ambiental actualizada'});
$('labMakeIllness').onclick=()=>doIt(()=>{const p=sim.people.find(x=>x.name===selected);p.illness=Math.min(100,p.illness+18);return 'Estado de salud registrado para '+selected});
$('labMakeInjury').onclick=()=>doIt(()=>{const p=sim.people.find(x=>x.name===selected);p.injury=Math.min(100,p.injury+18);return 'Lesión simulada registrada para '+selected});
$('labBirths').onchange=()=>doIt(()=>{sim.setCommunityOption('births',$('labBirths').checked);return 'Regla de generaciones actualizada'});
$('labApplyBirths').onclick=()=>doIt(()=>{sim.setCommunityOption('yearlyBirthRate',Number($('labBirthRate').value));return 'Tasa anual ficticia actualizada'});
$('labAddFounder').onclick=()=>doIt(()=>{const p=sim.createFounder();return 'Ha llegado '+p.name});
$('labNewWorld').onclick=()=>{const qty=Number($('labInitial').value);if(!Number.isInteger(qty)||qty<2||qty>20){msg('Elige entre 2 y 20 habitantes');return}if(!confirm('¿Crear un mundo completamente nuevo con '+qty+' habitantes? Exporta tu partida actual antes para no perderla.'))return;doIt(()=>{sim.reset(Math.floor(Math.random()*1e9)+1);for(let i=2;i<qty;i++)sim.createFounder();view.createTerrain();view.centerBoth();refresh(true);return 'Nuevo mundo: '+qty+' habitantes iniciales.'})};
$('labApplyCapacity').onclick=()=>doIt(()=>{sim.setCommunityOption('maxPopulation',Number($('labCapacity').value));return 'Límite actualizado a '+sim.community.maxPopulation});
$('labEnvironment').onclick=()=>doIt(()=>{const s=sim.populationStats();return `Habitantes ${s.living} / capacidad ${s.capacity}, arbustos ${sim.bushes.length}, humedad ${Math.round(sim.nature.moisture)}%.`});
$('labMigration').onclick=()=>doIt(()=>{const old=sim.community.totalMigrated;sim.advanceYears(1);return `Desplazamientos simulados: ${sim.community.totalMigrated-old}.`});
$('labStress').onclick=()=>{try{const Test=window.GenesisCore.GenesisEngine,t=new Test(9071);t.community.mortality=false;for(let i=0;i<10;i++)t.createFounder();const start=performance.now();for(let n=0;n<300;n++)t.step(window.GenesisCore.DT);msg(`Prueba independiente completada: 300 pasos, ${t.populationStats().living} agentes en ${Math.round(performance.now()-start)} ms. La partida activa no cambió.`)}catch(e){msg('Prueba fallida: '+e.message)}};
let lastTick=-1;function loop(){if(sim.tick!==lastTick){lastTick=sim.tick;refresh()}requestAnimationFrame(loop)}refresh(true);requestAnimationFrame(loop);
window.GenesisPopulationDebug={sim,stats:()=>sim.populationStats(),advance:y=>sim.advanceYears(y),addFounder:()=>sim.createFounder(),snapshot:()=>sim.snapshot(),load:s=>{sim.load(s);refresh(true)},version:STAGE};
})();
