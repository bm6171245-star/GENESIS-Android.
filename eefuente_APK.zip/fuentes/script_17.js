
(function(){'use strict';
const STAGE=60,api=window.GenesisNatureAccess;if(!api)return;
const sim=api.sim;window.GenesisHeritageUI={sim,stage:STAGE};
function el(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e}
function render(host){host.replaceChildren();host.append(el('p','historyIntro','Cada persona conserva una historia diferente. Elige una acción para probarla.'));
const chooser=el('label','historyLine','Habitante '),sel=el('select');for(const p of sim.people.filter(p=>p.alive!==false)){const o=el('option','',p.name);o.value=p.name;sel.append(o)}chooser.append(sel);host.append(chooser);
const otherLabel=el('label','historyLine','Con quién '),other=el('select');for(const p of sim.people.filter(p=>p.alive!==false)){const o=el('option','',p.name);o.value=p.name;other.append(o)}otherLabel.append(other);host.append(otherLabel);if(other.options.length>1)other.selectedIndex=1;
const actionLabel=el('label','historyLine','Actividad '),action=el('select');const options=[['symbol',51,'Crear símbolo'],['message',52,'Enviar mensaje'],['teach',53,'Enseñar conocimiento'],['inscribe',54,'Dejar inscripción'],['tradition',55,'Celebrar tradición'],['genealogy',56,'Ver familia'],['biography',57,'Ver biografía'],['timeline',58,'Ver cronología'],['ruins',59,'Registrar ruinas'],['archive',60,'Consultar archivo universal']];
for(const [key,stage,title] of options){if(STAGE<stage)continue;const o=el('option','',title);o.value=key;action.append(o)}actionLabel.append(action);host.append(actionLabel);
const textLabel=el('label','historyLine','Texto o significado '),txt=el('input');txt.maxLength=100;txt.value='Paz';txt.placeholder='Escribe aquí';textLabel.append(txt);host.append(textLabel);
const group=el('div','historyActions');const run=el('button','primary','Realizar acción'),view=el('button','','Ver acontecimientos');group.append(run,view);host.append(group);
const report=el('div','historyReport','Elige una actividad y pulsa Realizar acción.');host.append(report);
function textResult(v){return typeof v==='string'?v:JSON.stringify(v,null,2)}
function showTimeline(){report.textContent=sim.heritage.events.slice(-12).reverse().map(e=>`Día ${e.day} · ${e.text}`).join('\n')||'Todavía no hay acontecimientos.';}
function apply(){try{let result;const name=sel.value,peer=other.value;
 switch(action.value){case'symbol':result=sim.makeSymbol(name,txt.value);break;
 case'message':result=sim.sendMessage(name,peer,'agua');break;
 case'teach':result=sim.teachKnowledge(name,peer,'cultivar');break;
 case'inscribe':result=sim.inscribe(name,txt.value);break;
 case'tradition':result=sim.celebrate(name,'Cosecha');break;
 case'genealogy':result=sim.genealogy(name);break;
 case'biography':result=sim.biography(name);break;
 case'timeline':result=sim.timeline().slice(-15);break;
 case'ruins':{const a=sim.civilization.settlements.find(v=>!v.abandoned&&!(v.people||[]).some(n=>sim.people.some(p=>p.name===n&&p.alive!==false)));if(!a)throw Error('No hay aldeas abandonadas. Las aldeas habitadas no pueden registrarse como ruinas.');result=sim.archiveVillage(a.name);break;}
 case'archive':result=sim.worldArchive();break;default:throw Error('Actividad no disponible');}
 report.textContent=textResult(result);api.persist(true);
 }catch(e){report.textContent='No se pudo realizar: '+e.message;}}
 run.onclick=apply;view.onclick=showTimeline;
 if(STAGE>=60){const exportButton=el('button','','Exportar archivo histórico');exportButton.onclick=()=>{const data=JSON.stringify(sim.worldArchive(),null,2);const url=URL.createObjectURL(new Blob([data],{type:'application/json'}));const a=el('a');a.href=url;a.download='genesis_060_archivo_historico.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)};host.append(exportButton)}
 const tip=el('small','historyTip','Los idiomas y las tradiciones son sistemas ficticios basados en reglas. El archivo se guarda con el mundo.');host.append(tip);
}
window.GenesisHeritageUI.render=render;
})();
