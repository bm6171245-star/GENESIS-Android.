
/* Interfaz de civilizaciones 041–050, complementaria a las anteriores. */
(function(){'use strict';const STAGE=50,$=id=>document.getElementById(id),api=window.GenesisNatureAccess;if(!api)return;
const {sim,view}=api;for(const e of $('civLab').querySelectorAll('[data-civ-stage]'))e.hidden=Number(e.dataset.civStage)>STAGE;
let prevNames='',prevVillages='';
function sync(force=false){const names=sim.people.filter(p=>p.alive!==false).map(p=>p.name).join('|');if(force||names!==prevNames){for(const id of ['civPerson','civOther']){const el=$(id),value=el.value;el.replaceChildren();for(const p of sim.people.filter(z=>z.alive!==false)){const opt=document.createElement('option');opt.value=p.name;opt.textContent=p.name;el.appendChild(opt)}if([...el.options].some(o=>o.value===value))el.value=value;}if($('civOther').options.length>1&&$('civPerson').value===$('civOther').value)$('civOther').selectedIndex=1;prevNames=names;}
const v=sim.civilization.settlements.map(x=>x.name).join('|');if(force||v!==prevVillages){const sel=$('civVillage');sel.replaceChildren();for(const obj of sim.civilization.settlements){const opt=document.createElement('option');opt.textContent=obj.name;opt.value=obj.name;sel.appendChild(opt)}prevVillages=v;}
const c=sim.civilization;$('civWood').textContent=c.stock.wood;$('civStone').textContent=c.stock.stone;$('civFood').textContent=c.stock.food;$('civShelters').textContent=c.shelters.length;$('civFarms').textContent=c.farms.length;$('civVillages').textContent=c.settlements.length;
$('civShare').checked=c.norms.shareFood;$('civReplant').checked=c.norms.replant;}
function person(){return $('civPerson').value||'Kaelor'}
function print(){const p=sim.people.find(z=>z.name===person());if(!p)return 'Sin habitante seleccionado';const z=window.GenesisCivilization.pouch(p),c=sim.civilization;return `${p.name} · ${c.roles[p.name]||'Sin oficio'}\nInventario: madera ${z.wood}, piedra ${z.stone}, alimentos ${z.food}, herramientas ${z.tools}\nDepósito: ${Object.values(c.stock).reduce((a,b)=>a+b,0)} / ${c.capacity} · reservas naturales: ${c.woodReserve} madera y ${c.stoneReserve} piedra\nHuertos: ${c.farms.length}, cosechas listas: ${c.farms.reduce((n,f)=>n+f.ready,0)} · Intercambios ${c.trades}\nAldeas: ${c.settlements.map(x=>x.name+(x.leader?' · coordinador '+x.leader:'')).join('; ')||'ninguna'}\nÚltimos sucesos: ${c.history.slice(0,2).join(' | ')||'sin registros'}`.replaceAll('\\n','\n');}
function action(fn){try{const ans=fn();api.persist(true);sync(true);view.draw();view.drawMinimap();$('civReport').textContent=(typeof ans==='string'?ans+'\n':'')+print()}catch(e){$('civReport').textContent='No se pudo completar: '+e.message+'\n'+print();}}
$('civPerson').onchange=()=>{$('civReport').textContent=print()};$('civInspect').onclick=()=>{$('civReport').textContent=print()};
$('civGatherWood').onclick=()=>action(()=>{sim.gatherMaterial(person(),'wood')});
$('civGatherStone').onclick=()=>action(()=>{sim.gatherMaterial(person(),'stone')});
$('civCraft').onclick=()=>action(()=>{sim.craftTool(person())});
$('civShelter').onclick=()=>action(()=>{sim.makeShelter(person())});
$('civFarm').onclick=()=>action(()=>{sim.makeFarm(person())});
$('civHarvest').onclick=()=>action(()=>{sim.harvestFarm(person())});
$('civDeposit').onclick=()=>action(()=>{sim.storeGoods(person(),$('civGood').value,Number($('civAmount').value))});
$('civTake').onclick=()=>action(()=>{sim.retrieveGoods(person(),$('civGood').value,Number($('civAmount').value))});
$('civWarehouse').onclick=()=>action(()=>{sim.buildWarehouse(person())});
$('civSetRole').onclick=()=>action(()=>{sim.assignRole(person(),$('civRole').value)});
$('civTrade').onclick=()=>action(()=>{sim.tradeGoods(person(),$('civOther').value)});
$('civFound').onclick=()=>action(()=>{sim.foundVillage(person(),$('civVillageName').value.trim())});
$('civElect').onclick=()=>action(()=>{sim.chooseLeader($('civVillage').value)});
$('civNorms').onclick=()=>action(()=>{sim.setNorm('shareFood',$('civShare').checked);sim.setNorm('replant',$('civReplant').checked)});
$('civBenchmark').onclick=()=>{try{const t=new window.GenesisCore.GenesisEngine(879234);t.community.mortality=false;for(let i=0;i<18;i++)t.createFounder();t.assignRole('Kaelor','Recolector');const start=performance.now();for(let i=0;i<300;i++)t.step(window.GenesisCore.DT);$('civReport').textContent=`Prueba aislada completada: 300 pasos, ${t.populationStats().living} habitantes, ${t.civilizationStats().settlements} aldeas, ${Math.round(performance.now()-start)} ms. Tu mundo no se modificó.`}catch(e){$('civReport').textContent='La prueba no se completó: '+e.message;}};
const oldDraw=view.draw.bind(view);view.draw=function(){oldDraw();const g=this.ctx,c=this.camera,w=this.canvas.width,h=this.canvas.height,scale=c.scale*this.canvas.width/Math.max(1,this.canvas.clientWidth);g.save();g.setTransform(scale,0,0,scale,w/2-c.x*scale,h/2-c.y*scale);window.GenesisVisual?.drawStructures(g,sim);g.restore()};
let frames=0;function pulse(){if(++frames%105===0){sync();if($('civReport').textContent.startsWith('Selecciona un habitante'))$('civReport').textContent=print();}requestAnimationFrame(pulse)}sync(true);pulse();
window.GenesisCivilizationDebug={stage:STAGE,sim,stats:()=>sim.civilizationStats(),snapshot:()=>sim.snapshot(),load:s=>{sim.load(s);sync(true)},refresh:()=>sync(true)};
})();
