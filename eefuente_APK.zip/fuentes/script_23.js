
/* GÉNESIS 100.1: diagnóstico no destructivo. El guardado sigue en formato 100. */
(function(){'use strict';
  const sim=window.GenesisNatureAccess?.sim;
  const Core=window.GenesisCore;
  function check(){
    if(!sim||!Core)return 'Motor todavía no disponible.';
    try{
      const now=sim.snapshot();
      const old=JSON.stringify(now);
      const clone=new Core.GenesisEngine(12345);
      clone.load(JSON.parse(old));
      const after=clone.snapshot();
      const same=after.people.length===now.people.length &&
        after.civilization?.settlements?.length===now.civilization?.settlements?.length &&
        after.cosmos?.planets?.length===now.cosmos?.planets?.length &&
        JSON.stringify(after.personRules)===JSON.stringify(now.personRules);
      const stateUnchanged=JSON.stringify(sim.snapshot())===old;
      const storage=[];
      for(const [name,key] of [
        ['autoguardado','genesis_origin_100_autosave'],
        ['copia automática','genesis_origin_100_backup'],
        ['respaldo protegido','genesis_origin_100_manual_backup']]){
        try{const raw=localStorage.getItem(key);if(!raw){storage.push(name+': vacío');continue}
          const wrapped=JSON.parse(raw);const body=wrapped.state||wrapped;
          const t=new Core.GenesisEngine(7321);t.load(body);
          storage.push(name+': legible ('+Math.ceil(raw.length/1024)+' KB)');
        }catch(e){storage.push(name+': ERROR '+e.message)}
      }
      return `Motor: ${same&&stateUnchanged?'correcto':'REVISAR'} · ${now.people.length} habitantes · ${now.civilization?.settlements?.length||0} aldeas · ${now.cosmos?.planets?.length||0} planetas.\n${storage.join('\n')}\nEsta prueba no cambia tu mundo. Haz una exportación JSON adicional para conservarlo fuera del navegador.`;
    }catch(e){return 'Comprobación incompleta: '+e.message}
  }
  window.GenesisStable1001={check,version:'100.1-estabilidad'};
  // Al abandonar la página, intentar conservar el estado actual sin rotar copias protegidas.
  window.addEventListener('pagehide',()=>{try{window.GenesisNatureAccess?.persist(true,false)}catch(_){}});
})();
