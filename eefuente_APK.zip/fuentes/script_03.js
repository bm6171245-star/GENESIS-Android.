
/* NatureEngine: additions layered on previous simulation. Features are enabled cumulatively. */
(function(root){'use strict';
const STAGE=20, {GenesisEngine,W,H,DT,clamp}=root.GenesisCore;
const proto=GenesisEngine.prototype;
const old={reset:proto.reset,load:proto.load,snapshot:proto.snapshot,step:proto.step,water:proto.water,biomeAt:proto.biomeAt,walkable:proto.walkable};
const TYPES=['bosque','pradera','desierto','colina','agua','tundra','sabana'];
const defaultNature=()=>({tiles:{},weather:'Despejado',weatherTimer:0,temperature:23,moisture:70,drought:false,events:true,eventCounter:0,animals:[],plantClock:0,worldType:'realista',lastWeather:'',rainfall:0});
const isNum=(v,a,b)=>typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b;
const tileKey=(x,y)=>`${Math.floor(x/24)},${Math.floor(y/24)}`;
function normalizeNature(src){
 if(src===undefined||src===null)return defaultNature();
 if(typeof src!=='object'||Array.isArray(src))throw Error('Datos de naturaleza no válidos');
 const n=defaultNature();if(src.tiles!==undefined){if(!src.tiles||typeof src.tiles!=='object'||Array.isArray(src.tiles)||Object.keys(src.tiles).length>320)throw Error('Demasiadas celdas modificadas');for(const [k,v] of Object.entries(src.tiles)){if(!/^(?:[0-5]?\d),(?:[0-3]?\d)$/.test(k)||!TYPES.includes(v))throw Error('Celda de terreno no válida');const [a,b]=k.split(',').map(Number);if(a>59||b>39)throw Error('Celda fuera de límites')}n.tiles={...src.tiles}}
 if(src.weather!==undefined){if(!['Despejado','Nublado','Lluvia'].includes(src.weather))throw Error('Clima incorrecto');n.weather=src.weather}
 for(const [k,a,b] of [['weatherTimer',0,1e8],['temperature',-60,90],['moisture',0,100],['eventCounter',0,1e6],['plantClock',0,1e10],['rainfall',0,1e8]]){if(src[k]!==undefined){if(!isNum(src[k],a,b))throw Error('Valor ambiental inválido: '+k);n[k]=src[k]}}
 for(const k of ['drought','events'])if(src[k]!==undefined){if(typeof src[k]!=='boolean')throw Error('Opción ambiental incorrecta');n[k]=src[k]}
 if(src.worldType!==undefined){if(!['realista','fantastico','mixto'].includes(src.worldType))throw Error('Tipo de mundo incorrecto');n.worldType=src.worldType}
 if(src.animals!==undefined){if(!Array.isArray(src.animals)||src.animals.length>36)throw Error('Fauna incompatible');n.animals=src.animals.map(a=>{if(!a||!isNum(a.x,0,W)||!isNum(a.y,0,H)||!isNum(a.energy,0,100)||!isNum(a.id,1,1000))throw Error('Animal no válido');return {id:Math.floor(a.id),x:a.x,y:a.y,energy:a.energy,dx:isNum(a.dx,-1,1)?a.dx:0,dy:isNum(a.dy,-1,1)?a.dy:0}})}
 return n;
}
proto.reset=function(...args){const v=old.reset.apply(this,args);this.nature=defaultNature();if(STAGE>=17)this.addAnimals(8);return v};
proto.water=function(x,y){const v=this.nature?.tiles?.[tileKey(x,y)];return v? v==='agua':old.water.call(this,x,y)};
proto.walkable=function(x,y){if(x<=15||y<=15||x>=W-15||y>=H-15)return false;const t=this.nature?.tiles?.[tileKey(x,y)];return t?t!=='agua':old.walkable.call(this,x,y)};
proto.biomeAt=function(x,y){if(this.water(x,y))return 'agua';const custom=this.nature?.tiles?.[tileKey(x,y)];if(custom)return custom;
 const v=old.biomeAt.call(this,x,y);
 if(STAGE>=12){if(y<92&&v==='pradera')return 'tundra';if(y>820&&v==='pradera')return 'sabana';}
 return v;
};
proto.paintCell=function(x,y,type){if(STAGE<11)throw Error('Editor todavía no disponible');if(!TYPES.slice(0,STAGE>=12?7:5).includes(type))throw Error('Bioma no reconocido');if(!isNum(x,0,W-1)||!isNum(y,0,H-1))throw Error('Punto fuera del mapa');const key=tileKey(x,y);if(!(key in this.nature.tiles)&&Object.keys(this.nature.tiles).length>=300)throw Error('Máximo 300 celdas editadas');
 const prior=this.nature.tiles[key];this.nature.tiles[key]=type;
 if(type==='agua' && this.people.some(p=>!this.walkable(p.x,p.y))){if(prior===undefined)delete this.nature.tiles[key];else this.nature.tiles[key]=prior;throw Error('No puedes inundar una celda ocupada por habitantes')}
 this.grid=null;for(const p of this.people){p.target=null;p.route=[];p.routeIndex=0;p.decision=0}
 this.bushes=this.bushes.filter(b=>this.walkable(b.x,b.y));this.note('El creador modificó el terreno: '+type+'.');return true;
};
proto.addAnimals=function(count){if(STAGE<17)return 0;let n=0;for(let i=0;i<count&&this.nature.animals.length<30;i++){const p=this.land(this.rand(30,W-30),this.rand(30,H-30));this.nature.animals.push({id:this.nature.animals.length+1,x:p.x,y:p.y,dx:0,dy:0,energy:70});n++}return n};
proto.triggerEvent=function(kind){if(STAGE<18)throw Error('Fenómenos no disponibles');if(!['tormenta','sequia'].includes(kind))throw Error('Fenómeno incorrecto');if(kind==='tormenta'){this.nature.weather='Lluvia';this.nature.moisture=clamp(this.nature.moisture+22,0,100);this.nature.rainfall+=22;this.nature.drought=false;this.note('Tormenta: aumenta la humedad del suelo.');}
 else {this.nature.moisture=clamp(this.nature.moisture-25,0,100);this.nature.drought=true;this.nature.weather='Despejado';this.note('Sequía: se reduce la reserva de agua del terreno.')}
 this.nature.eventCounter++;};
proto.setWorldType=function(type){if(STAGE<19)throw Error('Mundos especiales no disponibles');if(!['realista','fantastico','mixto'].includes(type))throw Error('Tipo de mundo no válido');this.nature.worldType=type;this.note('El mundo ahora tiene estilo '+type+'.')};
proto.step=function(dt=DT){old.step.call(this,dt);const n=this.nature;if(!n)return;
 if(STAGE>=13){n.weatherTimer+=dt; // un cambio a intervalos fijos, usando la semilla del motor
  if(n.weatherTimer>=18){n.weatherTimer%=18;const r=this.next();n.weather=r<.22?'Lluvia':r<.52?'Nublado':'Despejado';if(n.lastWeather!==n.weather&&this.tick%30===0)this.note('Clima: '+n.weather.toLowerCase()+'.');n.lastWeather=n.weather}
 }
 if(STAGE>=14){const season=this.seasonName();const cycle=['primavera','verano','otoño','invierno'].indexOf(season);const temp=[21,30,17,8][cycle];n.temperature=temp+(n.weather==='Lluvia'?-3:0)+(n.worldType==='fantastico'?4:0)}
 if(STAGE>=12 && this.tick%3===0){for(const b of this.bushes){const biome=this.biomeAt(b.x,b.y);if(biome==='tundra')b.fruit=clamp(b.fruit-dt*.006,0,5);else if(biome==='sabana')b.fruit=clamp(b.fruit+dt*.003,0,5)}}
 if(STAGE>=13 && n.weather==='Lluvia'){for(const b of this.bushes)b.fruit=clamp(b.fruit+dt*.009,0,5)}
 if(STAGE>=14){for(const p of this.people){if(n.temperature<12)p.energy=clamp(p.energy-dt*.05,0,100);if(n.temperature>28)p.thirst=clamp(p.thirst-dt*.045,0,100)}}
 if(STAGE>=15){const mult=n.weather==='Lluvia'?.031:n.weather==='Nublado'?.002:-.009;
  n.moisture=clamp(n.moisture+dt*mult*(n.drought?1.6:1),0,100);if(n.drought&&n.moisture>65)n.drought=false;
  if(n.moisture<20&&this.tick%160===0)this.note('El suelo está muy seco: las plantas tardarán más en recuperarse.');
  if(n.moisture<30||n.drought){for(const b of this.bushes)b.fruit=clamp(b.fruit-dt*.022,0,5)}
 }
 if(STAGE>=16){n.plantClock+=dt;for(const b of this.bushes)b.age=(b.age||0)+dt/300;
   if(n.plantClock>=12){n.plantClock-=12;if(this.bushes.length<430 && n.moisture>35){const seeds=this.bushes.filter(b=>b.fruit>2 && (b.age||0)>.02);if(seeds.length){const b=seeds[Math.floor(this.next()*seeds.length)];const x=b.x+this.rand(-80,80),y=b.y+this.rand(-80,80);if(this.walkable(x,y)){const count=this.bushes.length;this.addBush(x,y);if(this.bushes.length>count)this.bushes[this.bushes.length-1].age=0}}}}
 }
 if(STAGE>=17 && this.tick%3===0){for(const a of n.animals){a.energy=clamp(a.energy+dt*(this.biomeAt(a.x,a.y)==='desierto'?-0.07:.06),0,100);if(this.next()<.08){const angle=this.rand(0,Math.PI*2);a.dx=Math.cos(angle);a.dy=Math.sin(angle)}const dx=a.dx*dt*45,dy=a.dy*dt*45;const xx=a.x+dx,yy=a.y+dy;if(this.walkable(xx,yy)){a.x=xx;a.y=yy}else{a.dx=-a.dx;a.dy=-a.dy}}}
 if(STAGE>=18 && n.events && this.tick%2300===0){const value=this.next();this.triggerEvent(value<.5?'tormenta':'sequia')}
};
proto.seasonName=function(){return ['primavera','verano','otoño','invierno'][Math.floor(((Math.floor(this.timeMin/1440))%36)/9)]};
proto.snapshot=function(){const s=old.snapshot.call(this);s.version=STAGE;s.release=String(STAGE).padStart(3,'0');s.nature=JSON.parse(JSON.stringify(this.nature||defaultNature()));return s};
proto.load=function(raw){if(raw&&raw.version>=11&&raw.version<=STAGE){const nat=normalizeNature(raw.nature);const compatible={...raw,version:10};old.load.call(this,compatible);this.nature=nat;
  if(STAGE>=16)for(const b of this.bushes){const oldBush=raw.bushes.find(x=>x.id===b.id);b.age=oldBush&&isNum(oldBush.age,0,1e5)?oldBush.age:0}
  this.grid=null;return;}
 old.load.call(this,raw);this.nature=defaultNature();if(STAGE>=17)this.addAnimals(8);
};
root.GenesisNatureVersion=STAGE;
root.GenesisNatureFeatures={stage:STAGE,types:TYPES};
})(typeof globalThis!=='undefined'?globalThis:this);
