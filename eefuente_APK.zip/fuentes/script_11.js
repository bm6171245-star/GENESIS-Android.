
/* GÉNESIS 010 · Modos de control y archivo de mundos. */
(function(){'use strict';
const $=id=>document.getElementById(id),{GenesisEngine,DT,W,H,clamp,DEFAULT_PERSON,DEFAULT_WORLD}=window.GenesisCore;
const KEY='genesis_origin_100_autosave',BACKUP='genesis_origin_100_backup',MANUAL='genesis_origin_100_manual_backup',SLOTBASE='genesis_origin_100_slot_',OLD=['genesis_origin_099_autosave','genesis_origin_098_autosave','genesis_origin_097_autosave','genesis_origin_096_autosave','genesis_origin_095_autosave','genesis_origin_094_autosave','genesis_origin_093_autosave','genesis_origin_092_autosave','genesis_origin_091_autosave','genesis_origin_090_autosave','genesis_origin_080_autosave','genesis_origin_089_autosave','genesis_origin_088_autosave','genesis_origin_087_autosave','genesis_origin_086_autosave','genesis_origin_085_autosave','genesis_origin_084_autosave','genesis_origin_083_autosave','genesis_origin_082_autosave','genesis_origin_081_autosave','genesis_origin_079_autosave','genesis_origin_078_autosave','genesis_origin_077_autosave','genesis_origin_076_autosave','genesis_origin_075_autosave','genesis_origin_074_autosave','genesis_origin_073_autosave','genesis_origin_072_autosave','genesis_origin_071_autosave','genesis_origin_069_autosave','genesis_origin_068_autosave','genesis_origin_067_autosave','genesis_origin_066_autosave','genesis_origin_065_autosave','genesis_origin_064_autosave','genesis_origin_063_autosave','genesis_origin_062_autosave','genesis_origin_061_autosave','genesis_origin_060_autosave','genesis_origin_059_autosave','genesis_origin_058_autosave','genesis_origin_057_autosave','genesis_origin_056_autosave','genesis_origin_055_autosave','genesis_origin_054_autosave','genesis_origin_053_autosave','genesis_origin_052_autosave','genesis_origin_051_autosave','genesis_origin_049_autosave','genesis_origin_048_autosave','genesis_origin_047_autosave','genesis_origin_046_autosave','genesis_origin_045_autosave','genesis_origin_044_autosave','genesis_origin_043_autosave','genesis_origin_042_autosave','genesis_origin_041_autosave','genesis_origin_040_autosave','genesis_origin_039_autosave','genesis_origin_038_autosave','genesis_origin_037_autosave','genesis_origin_036_autosave','genesis_origin_035_autosave','genesis_origin_034_autosave','genesis_origin_033_autosave','genesis_origin_032_autosave','genesis_origin_031_autosave','genesis_origin_030_autosave','genesis_origin_029_autosave','genesis_origin_028_autosave','genesis_origin_027_autosave','genesis_origin_026_autosave','genesis_origin_025_autosave','genesis_origin_024_autosave','genesis_origin_023_autosave','genesis_origin_022_autosave','genesis_origin_021_autosave','genesis_origin_020_autosave','genesis_origin_019_autosave','genesis_origin_018_autosave','genesis_origin_017_autosave','genesis_origin_016_autosave','genesis_origin_015_autosave','genesis_origin_014_autosave','genesis_origin_013_autosave','genesis_origin_012_autosave','genesis_origin_011_autosave','genesis_origin_010_autosave','genesis_origin_009_autosave','genesis_origin_009_backup','genesis_origin_008_v1','genesis_origin_007_v1','genesis_origin_006_v1','genesis_origin_005_v1','genesis_origin_004_v1','genesis_origin_003_v1','genesis_origin_002_v1','genesis_origin_001_v3'];
const sim=new GenesisEngine(267013),view=new window.GenesisView($('world'),$('minimap'),sim);
window.GenesisNatureAccess={sim,view,persist:(...args)=>persist(...args),note:(...args)=>note(...args),setMode:(...args)=>setGameMode(...args)};
let paused=false,rate=1,planting=false,last=0,acc=0,uiAge=0,miniAge=0,saveAge=0,frames=0,fps=0,fpsAge=0;
const RATES=[.5,1,2,3,4,8];let jumpState=null;let gameMode='observer',controlName='Kaelor',removing=false;
function updateSpeed(){ $('timeRate').value=String(rate);$('speed').textContent=`Tiempo ${String(rate).replace('.',',')}×`; }
function updateJumpStatus(){
 const active=!!jumpState;
 $('stopJump').disabled=!active;$('stepOne').disabled=active;
 for(const b of document.querySelectorAll('[data-jump]'))b.disabled=active;
 if(active){const done=jumpState.total-jumpState.remaining,pct=Math.min(100,done/jumpState.total*100);
  $('timeProgress').textContent=`Simulando ${jumpState.minutes===1440?'1 día':jumpState.minutes===60?'1 hora':'10 minutos'} · ${Math.floor(pct)} % · puedes detenerlo.`;
  $('timeProgressFill').style.width=pct+'%';
 }else {$('timeProgress').textContent='Sin salto temporal en curso.';$('timeProgressFill').style.width='0%'}
}
function stopJump(message='Salto detenido.'){if(!jumpState)return;const done=jumpState.total-jumpState.remaining;jumpState=null;paused=true;acc=0;updateJumpStatus();$('pause').textContent='▶ Reanudar';updateUI();persist(true);note(message+` Se aplicaron ${done} pasos del motor.`)}
function startJump(minutes){
 if(jumpState)return;const total=Math.round(minutes/(DT*15));jumpState={minutes,total,remaining:total};paused=true;acc=0;
 $('pause').textContent='▶ Reanudar';updateJumpStatus();updateUI();note('Salto temporal iniciado. Todos los habitantes siguen tomando decisiones.');
}

const note=s=>$('notice').textContent=s;
const ruleKeys=Object.keys(DEFAULT_PERSON);let selected='Kaelor',dirty=false;
function readRules(){return Object.fromEntries(ruleKeys.map(k=>[k,Number($(k).value)]))}
function syncRules(){
 for(const k of ruleKeys){$(k).value=sim.personRules[selected][k];$(k+'Value').textContent=sim.personRules[selected][k]+'%'}
 $('growth').value=sim.rules.growth;$('growthValue').textContent=sim.rules.growth+'%';$('editingName').textContent=selected;
 for(const name of ['Kaelor','Ilyra']){const tab=$('select'+name);tab.classList.toggle('active',selected===name);tab.setAttribute('aria-pressed',String(selected===name));const p=sim.personRules[name];$('rules'+name).textContent=`${name}: comida ${p.foodAt}% · agua ${p.waterAt}% · descanso ${p.restAt}% · consumo ${p.metabolism}% · recuperación ${p.recovery}%`}
 $('lawState').textContent='Configuración de '+selected+' actualizada';$('terrainPreset').value=sim.terrainPreset;dirty=false;
}
function previewRules(){for(const k of ruleKeys)$(k+'Value').textContent=$(k).value+'%';dirty=true;$('lawState').textContent='Cambios de '+selected+' sin aplicar'}
function selectPerson(name){if(dirty&&!confirm('Hay cambios sin aplicar. ¿Descartarlos?'))return;selected=name;syncRules();note('Editando solamente a '+name+'.')}
function setGameMode(mode,name=controlName,silent=false){
 if(!['observer','creator','character'].includes(mode))mode='observer';
 gameMode=mode;controlName=['Kaelor','Ilyra'].includes(name)?name:'Kaelor';
 document.body.dataset.gameMode=mode;
 $('creatorTools').hidden=mode!=='creator';$('characterTools').hidden=mode!=='character';$('controlledPerson').value=controlName;
 for(const [m,id] of [['observer','modeObserver'],['creator','modeCreator'],['character','modeCharacter']]){$(id).classList.toggle('active',mode===m);$(id).setAttribute('aria-pressed',String(mode===m))}
 for(const key of ['Observer','Creator','Character'])$('mode'+key).setAttribute('aria-pressed',String(mode===key.toLowerCase()));
 planting=false;removing=false;$('plant').classList.remove('active');$('removeBush').classList.remove('active');$('creatorPlant').classList.remove('active');$('creatorRemove').classList.remove('active');
 if(mode==='character'){sim.setManualName(controlName,silent);view.follow=controlName.toLowerCase();charHeld.clear()}else{sim.setManualName(null);charHeld.clear()}sim.setManualVector(0,0);
 const help={observer:'Solo observación: mueve la cámara y toca un habitante para seguirlo.',creator:'Creador: toca Sembrar o Quitar y después el terreno; también puedes modificar las leyes.',character:'Personaje: camina con flechas/WASD o toca un destino. '+controlName+' recibe tus órdenes y el otro sigue en automático.'};
 $('modeHelp').textContent=help[mode];$('sceneHint').textContent=mode==='character'?'Flechas para caminar · toca un destino':mode==='creator'?'Elige una herramienta y toca el terreno':'Arrastra para explorar · pellizca para zoom';
 if(!silent)note('Modo '+({observer:'Observador',creator:'Creador',character:'Personaje'})[mode]+'.');
 cameraUI();
}
function cameraUI(){const label=view.follow==='both'?'ambos':view.follow==='kaelor'?'Kaelor':view.follow==='ilyra'?'Ilyra':'libre';$('cameraMode').textContent=view.follow==='free'?'Libre':`Siguiendo a ${label}`;$('center').textContent=`◎ Seguir: ${label}`;$('zoomValue').textContent=Math.round(view.camera.scale*100)+'%'}
function updateUI(){window.GenesisNatureTools?.update?.();const t=sim.dateText();$('day').textContent=t.d;$('hour').textContent=t.txt;$('berries').textContent=sim.bushes.filter(b=>b.fruit>=1).length;$('modeLabel').textContent=paused?'Ⅱ PAUSA':'● ACTIVO';$('modeLabel').style.color=paused?'#f4dfa4':'#b4edd4';$('weather').textContent=({valle:'Valle · biomas mixtos',bosque:'Región de bosques',arido:'Región árida'})[sim.terrainPreset];if(sim.nature)$('weather').textContent+=' · '+sim.nature.weather;$('tick').textContent=sim.tick.toLocaleString('es');$('seed').textContent=sim.seed;$('fps').textContent=fps;$('timeDisplay').textContent=`Día ${t.d} · ${t.txt}`;$('timeMeta').textContent=`Velocidad ${String(rate).replace('.',',')}× · ${sim.tick.toLocaleString('es')} pasos`;cameraUI();
  sim.people.slice(0,2).forEach((p,i)=>{ $('task'+i).textContent=p.act;const bar=(label,n,cls)=>`<div class="barline"><span>${label}</span><div class="track"><span class="fill ${cls}" style="width:${Math.round(n)}%"></span></div><em>${Math.round(n)}</em></div>`; $('bars'+i).innerHTML=bar('Comida',p.hunger,'')+bar('Agua',p.thirst,'water')+bar('Energía',p.energy,'energy')+bar('Vitalidad',p.vitality,'vitality');const risk=$('risk'+i);risk.textContent=p.vitality<35?'Vitalidad crítica':p.riskLevel?'Alerta por escasez':'Estado estable';risk.className='risk'+(p.vitality<35?' danger':p.riskLevel?' warning':'')});
  sim.people.slice(0,2).forEach((p,i)=>{const meters=p.target?Math.round(Math.hypot(p.x-p.target.x,p.y-p.target.y))+' m al destino':'sin desplazamiento';const segments=p.target?(' · ruta '+Math.max(1,(p.route?.length||1)-(p.routeIndex||0))+' tramos'):'';$('plan'+i).textContent=p.act+' · '+meters+segments;$('decision'+i).textContent=(p.goalReason||'Evaluando el entorno')+' · '+(p.decisionsMade||0)+' decisiones'});
  // textContent en vez de HTML: los eventos importados nunca se interpretan como código.
  const root=$('log');root.replaceChildren();for(const e of sim.logs.slice(0,7)){const li=document.createElement('li'),time=document.createElement('time');time.textContent=e.t;li.append(time,document.createTextNode(e.msg));root.append(li)}
}
function snapshot(){return {...sim.snapshot(),release:'100',camera:{...view.camera},rate,paused,followMode:view.follow,gameMode,controlName}}
// FNV-1a 32-bit: detecta daños accidentales; no proporciona seguridad criptográfica.
function checksum(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}
function envelope(state){const serial=JSON.stringify(state);return {format:'genesis-save-v1',project:'GENESIS',release:'100',savedAt:new Date().toISOString(),checksum:checksum(serial),state}}
function stateFromFile(obj){if(!obj||typeof obj!=='object'||Array.isArray(obj))throw Error('Formato no reconocido');
 let s=obj;
 if(obj.format!==undefined){if(obj.format!=='genesis-save-v1'||obj.project!=='GENESIS'||!obj.state||typeof obj.checksum!=='string')throw Error('Formato de respaldo incompatible');if(checksum(JSON.stringify(obj.state))!==obj.checksum)throw Error('Suma de comprobación incorrecta: archivo alterado o incompleto');s=obj.state}
 if(s.project&&s.project!=='GENESIS')throw Error('El archivo pertenece a otro proyecto');
 const test=new GenesisEngine(9001);test.load(s); // Validar antes de tocar la partida activa.
 return s;
}
function readLocal(key){const value=localStorage.getItem(key);if(!value)return null;return {object:JSON.parse(value),raw:value,state:stateFromFile(JSON.parse(value))}}
function writeLocal(key,obj){const raw=JSON.stringify(obj);localStorage.setItem(key,raw);if(localStorage.getItem(key)!==raw)throw Error('No se pudo comprobar el guardado');return true}
function stamp(d){try{return new Date(d).toLocaleString('es-CO',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}catch{return 'fecha desconocida'}}
function describe(s,date){const day=Math.max(1,Math.floor(((s.timeMin||0)/1440)+1));return `Día ${day} · ${s.terrainPreset||'valle'} · ${stamp(date)}`}
function redrawArchive(){let main='Sin autoguardado',back='Sin respaldo',bad='';try{const v=readLocal(KEY);if(v)main=describe(v.state,v.object.savedAt); }catch(e){bad='Autoguardado dañado. ';main='No válido'}
 try{const v=readLocal(BACKUP);if(v)back=describe(v.state,v.object.savedAt)}catch(e){bad+='Respaldo dañado. ';back='No válido'}
 let protectedCopy='No creado';try{const saved=readLocal(MANUAL);if(saved)protectedCopy=describe(saved.state,saved.object.savedAt)}catch(e){protectedCopy='No válido';bad+='Respaldo protegido dañado. '}
 $('archiveStatus').textContent=`Auto: ${main} · Copia automática: ${back} · Respaldo protegido: ${protectedCopy}${bad?' · '+bad:''}`;
 for(let i=1;i<=3;i++){let label='Vacío',valid=false;try{const v=readLocal(SLOTBASE+i);if(v){valid=true;label=describe(v.state,v.object.savedAt)}}catch(e){label='No válido: '+e.message}
 $('slotInfo'+i).textContent=label;$('slotLoad'+i).disabled=!valid;$('slotDelete'+i).disabled=label==='Vacío';}
 $('restoreBackup').disabled=!restorableBackup()
}
function persist(silent=false,rotate=true){try{const next=envelope(snapshot());
 if(rotate){try{const current=readLocal(KEY);if(current)writeLocal(BACKUP,current.object)}catch(e){console.warn('No se rota una copia principal dañada:',e.message)}}
 writeLocal(KEY,next);if(!silent)note('Autoguardado completo y verificado.');redrawArchive();return true
 }catch(e){if(!silent)note('Error de almacenamiento: '+e.message+' · Exporta tu mundo.');return false}}
function restorableBackup(){for(const key of [MANUAL,BACKUP]){try{const saved=readLocal(key);if(saved)return saved}catch(e){console.warn('Copia de seguridad incompatible:',e.message)}}return null}
function backupCurrent(){try{writeLocal(MANUAL,envelope(snapshot()));redrawArchive();return true}catch(e){note('No se pudo crear respaldo protegido: '+e.message);return false}}
function applyState(s){if(jumpState)stopJump('Salto cancelado al importar.');sim.load(s);syncRules();view.createTerrain();const c=s.camera||{};view.camera={x:Number.isFinite(c.x)?c.x:W/2,y:Number.isFinite(c.y)?c.y:H/2,scale:clamp(Number.isFinite(c.scale)?c.scale:1.1,.2,3.2)};view.follow=['both','kaelor','ilyra','free'].includes(s.followMode)?s.followMode:'both';paused=!!s.paused;rate=RATES.includes(s.rate)?s.rate:1;acc=0;updateSpeed();updateJumpStatus();$('pause').textContent=paused?'▶ Reanudar':'Ⅱ Pausar';setGameMode(s.gameMode||'observer',s.controlName||'Kaelor',true);view.bound();view.draw();view.drawMinimap();updateUI()}
function loadSafely(s,description){stateFromFile(s);if(!confirm('¿Cargar '+description+'? La partida activa se reemplazará. Guarda una copia manual o exporta antes si quieres conservarla.'))return false;
 // Respalda la partida activa antes de sustituirla; si falla, no arriesgamos una pérdida silenciosa.
 if(!backupCurrent()){note('No se cargó: primero exporta la partida activa como JSON.');return false}
 applyState(s);persist(true,false);redrawArchive();note(description+' cargado. El mundo anterior quedó en el respaldo protegido.');return true}
function restore(){for(const key of [KEY,BACKUP,MANUAL,...OLD]){try{const v=readLocal(key);if(!v)continue;applyState(v.state);if(key!==KEY){try{writeLocal(KEY,envelope(snapshot()))}catch(_){}}
 note(key===BACKUP?'Autoguardado principal no válido; recuperado el respaldo.':key===KEY?'Partida automática recuperada.':'Mundo antiguo recuperado y migrado al formato 030.');redrawArchive();return true}catch(e){console.warn('Partida no recuperable de',key,e.message)}}redrawArchive();return false}
function fresh(preset=sim.terrainPreset){if(jumpState)stopJump('Salto cancelado al crear un mundo.');const seed=(Math.floor(Math.random()*1e9)+1)>>>0;sim.reset(seed,preset);syncRules();view.createTerrain();view.camera.scale=1.1;view.centerBoth();paused=false;rate=1;planting=false;acc=0;$('plant').classList.remove('active');updateSpeed();updateJumpStatus();$('pause').textContent='Ⅱ Pausar';setGameMode('observer','Kaelor',true);updateUI();view.draw();view.drawMinimap()}
let pointers=new Map(),gesture=null,dragged=false,hadMultiple=false;
function pinched(){const pts=[...pointers.values()],a=pts[0],b=pts[1];return{x:(a.x+b.x)/2,y:(a.y+b.y)/2,distance:Math.max(10,Math.hypot(b.x-a.x,b.y-a.y))}}
$('world').addEventListener('pointerdown',e=>{e.preventDefault();try{e.currentTarget.setPointerCapture(e.pointerId)}catch(_){}pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===1){dragged=false;hadMultiple=false;gesture={startX:e.clientX,startY:e.clientY,cx:view.camera.x,cy:view.camera.y}}else if(pointers.size===2){hadMultiple=true;dragged=true;const p=pinched();gesture={pinch:p.distance,scale:view.camera.scale}}});
$('world').addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;const p=pointers.get(e.pointerId);p.x=e.clientX;p.y=e.clientY;
 if(pointers.size>=2){const p=pinched();if(!gesture?.pinch)gesture={pinch:p.distance,scale:view.camera.scale};view.zoomAt(p.x,p.y,gesture.scale*p.distance/gesture.pinch);view.follow='free';dragged=true;cameraUI();return}
 if(!gesture||gesture.startX===undefined)return;const dx=e.clientX-gesture.startX,dy=e.clientY-gesture.startY;if(Math.hypot(dx,dy)>6){dragged=true;view.follow='free';view.camera.x=gesture.cx-dx/view.camera.scale;view.camera.y=gesture.cy-dy/view.camera.scale;view.bound();cameraUI()}
});
function release(e,cancelled=false){if(!pointers.has(e.pointerId))return;pointers.delete(e.pointerId);
 if(!cancelled&&!dragged&&!hadMultiple&&pointers.size===0){const p=view.point(e.clientX,e.clientY);
 if(gameMode==='character'){
  if(sim.directPersonTo(controlName,p)){view.showDestinations=true;$('goals').textContent='Ocultar rutas';note(controlName+' seguirá el camino elegido.');}
  else note('Destino bloqueado o inaccesible. Toca tierra transitable.');
 } else if(gameMode==='creator'&&window.GenesisNatureTools?.selectedTool&&!planting&&!removing){window.GenesisNatureTools.paint(p)}
 else if(gameMode==='creator'&&planting){if(sim.walkable(p.x,p.y)){if(sim.addBush(p.x,p.y)){sim.note('El creador sembró un arbusto.');note('Se plantó un arbusto en el valle.')}else note('Ya hay un arbusto muy cerca.')}else note('Elige tierra firme para sembrar.')}
 else if(gameMode==='creator'&&removing){const index=sim.bushes.findIndex(b=>Math.hypot(b.x-p.x,b.y-p.y)<25/view.camera.scale);if(index>=0){sim.bushes.splice(index,1);sim.note('El creador retiró un arbusto.');note('Arbusto retirado.')}else note('No hay arbustos cerca del punto tocado.');}
 else{const who=sim.people.find(h=>Math.hypot(h.x-p.x,h.y-p.y)<28/view.camera.scale);if(who){view.follow=who.name.toLowerCase();note(`Ahora sigues a ${who.name}.`)}else note('Bioma: '+({agua:'río',bosque:'bosque',pradera:'pradera',desierto:'desierto',colina:'colina'})[sim.biomeAt(p.x,p.y)]+'.')}
 updateUI()}
 if(pointers.size===1){const p=[...pointers.values()][0];gesture={startX:p.x,startY:p.y,cx:view.camera.x,cy:view.camera.y};dragged=true}else if(pointers.size===0){gesture=null;dragged=false;hadMultiple=false}
}
$('world').addEventListener('pointerup',e=>release(e));$('world').addEventListener('pointercancel',e=>release(e,true));
$('world').addEventListener('wheel',e=>{e.preventDefault();view.follow='free';view.zoomAt(e.clientX,e.clientY,view.camera.scale*(e.deltaY>0?.88:1.14));cameraUI()},{passive:false});
$('minimap').addEventListener('pointerdown',e=>{e.preventDefault();const r=e.currentTarget.getBoundingClientRect();view.camera.x=clamp((e.clientX-r.left)/r.width*W,0,W);view.camera.y=clamp((e.clientY-r.top)/r.height*H,0,H);view.follow='free';view.bound();view.drawMinimap();cameraUI();note('Cámara desplazada desde el minimapa.')});
const panHeld=new Set(),charHeld=new Set();function pan(dt){if(!panHeld.size)return;const vx=Number(panHeld.has('right'))-Number(panHeld.has('left')),vy=Number(panHeld.has('down'))-Number(panHeld.has('up'));if(!vx&&!vy)return;const len=Math.hypot(vx,vy);view.camera.x+=vx/len*dt*240/view.camera.scale;view.camera.y+=vy/len*dt*240/view.camera.scale;view.bound()}
for(const b of document.querySelectorAll('[data-dir]')){const dir=b.dataset.dir;b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}panHeld.add(dir);view.follow='free';cameraUI()});const stop=()=>panHeld.delete(dir);for(const type of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(type,stop);b.addEventListener('contextmenu',e=>e.preventDefault())}
function directionForKey(k){return ({ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',w:'up',s:'down',a:'left',d:'right'})[k]||null}
function updateManualVector(){if(gameMode!=='character'){sim.setManualVector(0,0);return}
 const dx=Number(charHeld.has('right'))-Number(charHeld.has('left')),dy=Number(charHeld.has('down'))-Number(charHeld.has('up'));sim.setManualVector(dx,dy)}
for(const b of document.querySelectorAll('[data-char-dir]')){const dir=b.dataset.charDir;
 b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}charHeld.add(dir);updateManualVector()});
 const stop=()=>{charHeld.delete(dir);updateManualVector()};for(const evt of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(evt,stop);
 b.addEventListener('contextmenu',e=>e.preventDefault());}
window.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
 const dir=directionForKey(e.key);if(!dir)return;e.preventDefault();if(gameMode==='character'){charHeld.add(dir);updateManualVector()}else if(e.key.startsWith('Arrow')){panHeld.add(dir);view.follow='free'}});
window.addEventListener('keyup',e=>{const dir=directionForKey(e.key);if(dir){panHeld.delete(dir);charHeld.delete(dir);updateManualVector()}});
window.addEventListener('blur',()=>{panHeld.clear();charHeld.clear();updateManualVector()});
$('pause').onclick=()=>{if(jumpState){note('Detén primero el salto temporal.');return}paused=!paused;acc=0;$('pause').textContent=paused?'▶ Reanudar':'Ⅱ Pausar';updateUI();note(paused?'Tiempo detenido.':'Tiempo en marcha.')};
$('speed').onclick=()=>{rate=RATES[(RATES.indexOf(rate)+1)%RATES.length];updateSpeed();persist(true);note(`Velocidad ${rate}×`)};
$('timeRate').onchange=()=>{const desired=Number($('timeRate').value);if(!RATES.includes(desired))return;rate=desired;updateSpeed();persist(true);note(`Velocidad ${rate}×`)};
$('stepOne').onclick=()=>{if(jumpState)return;paused=true;acc=0;sim.step(DT);$('pause').textContent='▶ Reanudar';updateUI();view.draw();persist(true);note('Se ejecutó un paso del motor (30 pasos representan 15 min simulados).')};
for(const b of document.querySelectorAll('[data-jump]'))b.addEventListener('click',()=>startJump(Number(b.dataset.jump)));
$('stopJump').onclick=()=>stopJump('Salto interrumpido por el usuario.');
$('center').onclick=()=>{const modes=['both','kaelor','ilyra','free'];view.follow=modes[(modes.indexOf(view.follow)+1)%modes.length];if(view.follow==='both')view.centerBoth();cameraUI()};
$('overview').onclick=()=>{view.overview();cameraUI();note('Vista general del Valle del Origen.')};
function setCreatorTool(which){if(gameMode!=='creator')setGameMode('creator');
 planting=which==='plant'&&!planting;removing=which==='remove'&&!removing;
 if(planting)removing=false;if(removing)planting=false;
 $('plant').classList.toggle('active',planting);$('removeBush').classList.toggle('active',removing);
 $('creatorPlant').classList.toggle('active',planting);$('creatorRemove').classList.toggle('active',removing);
 $('sceneHint').textContent=planting?'Toca tierra firme para sembrar':removing?'Toca un arbusto para quitarlo':'Arrastra · pellizca para explorar';
 note(planting?'Herramienta Sembrar activada.':removing?'Herramienta Quitar activada.':'Herramienta desactivada.');}
$('plant').onclick=()=>setCreatorTool('plant');$('removeBush').onclick=()=>setCreatorTool('remove');
$('creatorPlant').onclick=()=>setCreatorTool('plant');$('creatorRemove').onclick=()=>setCreatorTool('remove');
$('creatorLaws').onclick=()=>$('lawEditor').scrollIntoView({behavior:'smooth',block:'start'});
$('modeObserver').onclick=()=>{setGameMode('observer');persist(true)};
$('modeCreator').onclick=()=>{setGameMode('creator');persist(true)};
$('modeCharacter').onclick=()=>{setGameMode('character');persist(true)};
$('controlledPerson').onchange=()=>{setGameMode('character',$('controlledPerson').value);persist(true)};
$('cancelDestination').onclick=()=>{const p=sim.people.find(x=>x.name===controlName);p.target=null;p.route=[];p.routeIndex=0;p.act='Bajo tu control';note('Destino cancelado para '+controlName);updateUI()};
$('zoomIn').onclick=()=>{view.zoomCenter(1.25);cameraUI()};$('zoomOut').onclick=()=>{view.zoomCenter(1/1.25);cameraUI()};
for(const k of ruleKeys)$(k).addEventListener('input',previewRules);
$('selectKaelor').onclick=()=>selectPerson('Kaelor');$('selectIlyra').onclick=()=>selectPerson('Ilyra');
$('applyLaws').onclick=()=>{try{sim.setPersonRules(selected,readRules());syncRules();persist(true);updateUI();note('Leyes aplicadas a '+selected+' sin modificar al otro habitante.')}catch(e){note(e.message)}};
$('copyLaws').onclick=()=>{if(dirty){note('Aplica los cambios primero.');return}const other=selected==='Kaelor'?'Ilyra':'Kaelor';sim.setPersonRules(other,{...sim.personRules[selected]});syncRules();persist(true);note('Leyes de '+selected+' copiadas a '+other+'.')};
$('resetLaws').onclick=()=>{sim.setPersonRules(selected,{...DEFAULT_PERSON});syncRules();persist(true);note('Restauradas solo las leyes de '+selected+'.')};
$('growth').addEventListener('input',()=>{$('growthValue').textContent=$('growth').value+'%'});
$('applyWorldLaws').onclick=()=>{try{sim.setWorldRules({growth:Number($('growth').value)});syncRules();persist(true);note('Regeneración del planeta actualizada.')}catch(e){note(e.message)}};
$('generateWorld').onclick=()=>{if(confirm('¿Generar un mundo nuevo con este terreno? El mundo actual será reemplazado en el guardado local. Exporta antes si quieres conservarlo.')){if(!backupCurrent()){note('Primero exporta tu mundo actual.');return}fresh($('terrainPreset').value);persist(true,false);note('Mundo nuevo generado · '+({valle:'valle equilibrado',bosque:'región boscosa',arido:'región árida'})[sim.terrainPreset]+'.')}};
$('goals').onclick=()=>{view.showDestinations=!view.showDestinations;$('goals').textContent=view.showDestinations?'Ocultar rutas':'Mostrar rutas';view.draw();note(view.showDestinations?'Rutas visibles en el mapa.':'Rutas ocultas.');};
$('reconsider').onclick=()=>{for(const p of sim.people){p.stay=0;p.decision=0;sim.choose(p)}updateUI();view.draw();note('Decisiones recalculadas con las reglas de cada habitante.');};
$('crossDemo').onclick=()=>{if(!confirm('Esto agotará temporalmente los frutos de la orilla de Kaelor y lo hará buscar alimento al otro lado. ¿Continuar?'))return;
  const p=sim.people.find(x=>x.name==='Kaelor'),bank=sim.side(p.x,p.y);
  for(const b of sim.bushes){if(sim.side(b.x,b.y)===bank)b.fruit=0}
  const other=sim.bushes.filter(b=>sim.side(b.x,b.y)!==bank&&b.fruit>=1);
  if(!other.length){const x=sim.riverX(p.y)-bank*(sim.riverWidth(p.y)+100);sim.addBush(x,p.y)}
  p.hunger=8;p.thirst=95;p.energy=95;p.stay=0;p.decision=0;p.target=null;p.route=[];
  sim.choose(p);view.showDestinations=true;$('goals').textContent='Ocultar rutas';view.follow='kaelor';view.draw();updateUI();persist(true);
  note(p.target?'Kaelor tiene una ruta de '+(p.route?.length||1)+' tramos. Reanuda el tiempo para ver el cruce.':'No se encontró ruta; prueba reiniciar el mundo.');
};
$('save').onclick=()=>persist(false);
function exportCurrent(){try{if(window.GenesisAndroid?.saveWorld){window.GenesisAndroid.saveWorld(JSON.stringify(envelope(snapshot()),null,2));note('Selecciona el destino para guardar el mundo JSON.');return;}const blob=new Blob([JSON.stringify(envelope(snapshot()),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='genesis_100_mundo_'+Date.now()+'.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(url);a.remove()},1200);note('Archivo JSON creado. Revisa que aparezca en Descargas.')}catch(e){note('Error al exportar: '+e.message)}}
$('export').onclick=exportCurrent;
$('import').onclick=()=>$('importFile').click();
$('importFile').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{if(f.size>8_000_000)throw Error('El archivo supera 8 MB');const raw=JSON.parse(await f.text());const s=stateFromFile(raw);loadSafely(s,'Archivo JSON verificado')}catch(err){note('Importación rechazada: '+err.message)}e.target.value=''});
$('reset').onclick=()=>{if(!confirm('¿Crear un mundo nuevo? El actual quedará como respaldo, si el almacenamiento funciona.'))return;if(!backupCurrent()){note('Primero exporta tu mundo, pues no fue posible crear el respaldo.');return}fresh();persist(true,false);note('Mundo nuevo generado. Mundo anterior guardado en el respaldo protegido.');};
for(let i=1;i<=3;i++){
 $('slotSave'+i).onclick=()=>{let existed=false;try{existed=!!localStorage.getItem(SLOTBASE+i)}catch(e){note('Almacenamiento bloqueado: '+e.message);return}
 if(existed&&!confirm('¿Sobrescribir el espacio '+i+'?'))return;try{writeLocal(SLOTBASE+i,envelope(snapshot()));redrawArchive();note('Partida guardada y verificada en espacio '+i+'.')}catch(e){note('No se pudo guardar en espacio '+i+': '+e.message)}};
 $('slotLoad'+i).onclick=()=>{try{const v=readLocal(SLOTBASE+i);if(v)loadSafely(v.state,'Espacio '+i)}catch(e){note('El espacio '+i+' no puede cargarse: '+e.message)} };
 $('slotDelete'+i).onclick=()=>{if(!confirm('¿Eliminar para siempre el espacio '+i+' de este navegador?'))return;try{localStorage.removeItem(SLOTBASE+i);redrawArchive();note('Espacio '+i+' eliminado.')}catch(e){note('No se pudo eliminar: '+e.message)}};
}
$('backupNow').onclick=()=>{if(backupCurrent())note('Respaldo protegido creado: no será reemplazado por los autoguardados. Guárdalo también como JSON si es importante.')};
$('restoreBackup').onclick=()=>{try{const v=restorableBackup();if(!v){note('No hay respaldo válido disponible.');return}if(!confirm('¿Restaurar el respaldo protegido (o, si no existe, la copia automática)? Se sustituirá tu partida activa. Exporta o guarda en un espacio manual antes.'))return;
 // No rotar el respaldo: conservarlo como último recurso.
 applyState(v.state);persist(true,false);note('Respaldo restaurado.');}catch(e){note('No se pudo restaurar el respaldo: '+e.message)}};
$('verifyArchive').onclick=()=>{const result=[];for(const [label,key] of [['automático',KEY],['copia automática',BACKUP],['respaldo protegido',MANUAL],...Array.from({length:3},(_,i)=>['espacio '+(i+1),SLOTBASE+(i+1)])]){try{const v=readLocal(key);if(v)result.push(label+' correcto')}catch(e){result.push(label+' dañado')}}redrawArchive();note(result.length?result.join(' · '):'Todavía no hay guardados locales.');};
$('diagnostics').onclick=()=>{const a=new GenesisEngine(81234),b=new GenesisEngine(81234);for(let i=0;i<180;i++){a.step(DT);b.step(DT)}const same=JSON.stringify(a.snapshot())===JSON.stringify(b.snapshot());note(same?`Motor independiente correcto · 180 pasos reproducibles · Mundo actual: ${sim.tick} pasos.`:'Error: dos simulaciones iguales produjeron estados diferentes.');$('diagnostics').textContent=same?'✓ Motor verificado':'! Motor no verificable'};
window.addEventListener('resize',()=>view.resize(),{passive:true});document.addEventListener('visibilitychange',()=>{last=performance.now();if(document.hidden)persist(true)});
function loop(now){
 if(!last)last=now;const dt=Math.min((now-last)/1000,.12);last=now;
 if(jumpState){
  const started=performance.now();let batch=0;
  while(jumpState && jumpState.remaining>0 && batch<70 && performance.now()-started<9){sim.step(DT);jumpState.remaining--;batch++}
  if(jumpState?.remaining===0){const minutes=jumpState.minutes;jumpState=null;paused=true;acc=0;updateJumpStatus();$('pause').textContent='▶ Reanudar';persist(true);note(`Salto completado: +${minutes===1440?'1 día':minutes===60?'1 hora':'10 min'}. Los habitantes y recursos fueron simulados.`)}
  else if(jumpState)updateJumpStatus();
 }else if(!paused){acc+=dt*rate;let n=0;while(acc>=DT&&n<42){sim.step(DT);acc-=DT;n++}if(n===42)acc=0}
 pan(dt);if(!panHeld.size)view.updateFollow(dt);view.draw();uiAge+=dt;miniAge+=dt;saveAge+=dt;fpsAge+=dt;frames++;
 if(fpsAge>=1){fps=Math.round(frames/fpsAge);fpsAge=0;frames=0}
 if(uiAge>.28){updateUI();uiAge=0}if(miniAge>.15){view.drawMinimap();miniAge=0}if(saveAge>25){persist(true);saveAge=0}
 requestAnimationFrame(loop)
}

if(!restore())fresh();
// Los espacios de la 009 se ofrecen como nuevos espacios solo si los de la 010 están vacíos.
for(let i=1;i<=3;i++){try{if(!localStorage.getItem(SLOTBASE+i)){const old=readLocal('genesis_origin_009_slot_'+i);if(old)writeLocal(SLOTBASE+i,envelope(old.state))}}catch(e){console.warn('Migración opcional del espacio',i,e.message)}}
redrawArchive();view.resize();updateUI();window.GenesisDebug={getState:()=>structuredClone(snapshot()),setPersonRules:(name,r)=>{sim.setPersonRules(name,r);syncRules();updateUI()},setWorldRules:r=>{sim.setWorldRules(r);syncRules();updateUI()},getBiome:(x,y)=>sim.biomeAt(x,y),step:(n=1)=>{for(let i=0;i<Math.min(n,10000);i++)sim.step(DT);updateUI();view.draw();return sim.tick},newSeed:(seed)=>{sim.reset(seed);setGameMode('observer','Kaelor',true);view.createTerrain();view.centerBoth();view.draw();updateUI()},version:30,setMode:(m,n)=>{setGameMode(m,n);updateUI()},getMode:()=>({mode:gameMode,controlled:controlName}),directTo:(x,y)=>sim.directPersonTo(controlName,{x,y}),manual:(dx,dy)=>sim.setManualVector(dx,dy),advanceMinutes:(m)=>{if(![10,60,1440].includes(m))throw Error('Salto no permitido');startJump(m)},isJumping:()=>!!jumpState,validateSave:(o)=>{stateFromFile(o);return true},saveSlot:(i)=>{if(![1,2,3].includes(i))throw Error('Espacio inválido');writeLocal(SLOTBASE+i,envelope(snapshot()));redrawArchive()},listSlots:()=>[1,2,3].map(i=>{try{return readLocal(SLOTBASE+i)?.state||null}catch{return null}}),choose:(name)=>{const p=sim.people.find(h=>h.name===name);if(!p)throw Error("Habitante no encontrado");sim.choose(p);updateUI();return {act:p.act,target:p.target,reason:p.goalReason}},reachable:(a,b)=>!!sim.findRoute(a,b),route:(a,b)=>sim.findRoute(a,b),walkable:(x,y)=>sim.walkable(x,y),fordY:()=>sim.fordY()};requestAnimationFrame(loop);
})();

