
/* GÉNESIS 031–040 · Cognición simulada: reglas y recuerdos explicables. */
(function(root){'use strict';
const STAGE=40,{GenesisEngine,DT,clamp,DEFAULT_PERSON}=root.GenesisCore,proto=GenesisEngine.prototype;
const old={reset:proto.reset,load:proto.load,snapshot:proto.snapshot,step:proto.step,choose:proto.choose,complete:proto.complete,selectFood:proto.selectFood,selectRiver:proto.selectRiver};
const KINDS=['comida','agua','sitio'];
const PREFS=['comida','agua','descanso','explorar'];
function fresh(){return {memories:[],knowledge:{comida:0,agua:0,descanso:0,explorar:0},attempts:{comida:0,agua:0,descanso:0,explorar:0},successes:{comida:0,agua:0,descanso:0,explorar:0},preferences:{comida:50,agua:50,descanso:50,explorar:50},signals:[],shared:0,communications:0,cooperations:0,role:'Explorador',lastGoal:'',lastMessageTick:0,seen:0};}
function validSpot(m){return m&&KINDS.includes(m.kind)&&Number.isFinite(m.x)&&m.x>=0&&m.x<=1440&&Number.isFinite(m.y)&&m.y>=0&&m.y<=960&&Number.isFinite(m.when)&&Number.isFinite(m.strength);}
function ensure(p){if(!p.mind||typeof p.mind!=='object')p.mind=fresh();const m=p.mind;
for(const k of ['knowledge','attempts','successes','preferences'])if(!m[k]||typeof m[k]!=='object')m[k]={...fresh()[k]};
for(const k of PREFS){if(!Number.isFinite(m.knowledge[k]))m.knowledge[k]=0;if(!Number.isFinite(m.attempts[k]))m.attempts[k]=0;if(!Number.isFinite(m.successes[k]))m.successes[k]=0;if(!Number.isFinite(m.preferences[k]))m.preferences[k]=50;}
if(!Array.isArray(m.memories))m.memories=[];if(!Array.isArray(m.signals))m.signals=[];
for(const k of ['shared','communications','cooperations','seen'])if(!Number.isFinite(m[k]))m[k]=0;
if(typeof m.role!=='string')m.role='Explorador';return m;}
function goalOf(act){return act?.includes('agua')||act?.includes('Agua')?'agua':act?.includes('comida')||act?.includes('Comiendo')||act?.includes('frutos')?'comida':act?.includes('Descans')?'descanso':'explorar';}
function record(sim,p,kind,x,y,strength=1){const m=ensure(p);if(!KINDS.includes(kind))return;const near=m.memories.find(z=>z.kind===kind&&Math.hypot(z.x-x,z.y-y)<25);if(near){near.when=sim.tick;near.strength=clamp(near.strength+.1,.05,1);near.x=x;near.y=y;}else{m.memories.push({kind,x,y,when:sim.tick,strength:clamp(strength,.05,1),from:'experiencia'});if(m.memories.length>24)m.memories.shift();}}
function reward(sim,p,kind,value){const m=ensure(p);if(!PREFS.includes(kind))return;m.attempts[kind]=Math.min(100000,m.attempts[kind]+1);if(value>0)m.successes[kind]=Math.min(100000,m.successes[kind]+1);
if(STAGE>=33)m.knowledge[kind]=clamp(m.knowledge[kind]+(value>0?1:-.35),-20,40);
if(STAGE>=38){const scores=[['Recolector',m.successes.comida],['Hidrólogo',m.successes.agua],['Explorador',m.successes.explorar],['Cuidador',m.successes.descanso]];scores.sort((a,b)=>b[1]-a[1]);m.role=scores[0][1]>=3?scores[0][0]:'Explorador';}}
proto.reset=function(...a){const r=old.reset.apply(this,a);this.cognition={learning:true,signals:true,cooperation:true,adaptation:35,totalSignals:0,totalShares:0,totalAid:0};this.people.forEach(p=>ensure(p));return r};
proto.remember=function(name,kind,x,y){const p=this.people.find(p=>p.name===name&&p.alive!==false);if(!p)throw Error('No se encontró el habitante');record(this,p,kind,x,y);return ensure(p).memories.length};
proto.setPreference=function(name,kind,val){if(STAGE<32)throw Error('Disponible desde 032');if(!PREFS.includes(kind)||!Number.isInteger(val)||val<0||val>100)throw Error('Preferencia fuera de rango');const p=this.people.find(p=>p.name===name);if(!p)throw Error('Habitante desconocido');ensure(p).preferences[kind]=val;p.decision=0;p.target=null;p.route=[];return val};
proto.selectFood=function(p){if(STAGE<34)return old.selectFood.call(this,p);const m=ensure(p),known=m.memories.filter(z=>z.kind==='comida'&&z.strength>.1);let best=old.selectFood.call(this,p),bestScore=best?.distance??Infinity;
for(const z of known){const b=this.bushes.find(b=>Math.hypot(b.x-z.x,b.y-z.y)<24&&b.fruit>=1);if(!b)continue;const route=this.findRoute(p,{x:b.x,y:b.y});if(!route)continue;const price=route.distance*.88;if(price>=bestScore)continue;best={pos:{x:b.x,y:b.y,bushId:b.id},distance:route.distance,route};bestScore=price;}return best;};
proto.selectRiver=function(p){if(STAGE<34)return old.selectRiver.call(this,p);const known=ensure(p).memories.filter(z=>z.kind==='agua'&&z.strength>.1);let best=old.selectRiver.call(this,p),bestScore=best?.distance??Infinity;
for(const z of known){const pos={x:z.x,y:z.y};if(!this.walkable(pos.x,pos.y)||Math.abs(pos.x-this.riverX(pos.y))>this.riverWidth(pos.y)+70)continue;const route=this.findRoute(p,pos);if(route&&route.distance*.88<bestScore){best={pos,distance:route.distance,route};bestScore=route.distance*.88;}}return best;};
proto.choose=function(p){const m=ensure(p);if(STAGE<32)return old.choose.call(this,p);
if(p.alive===false)return;const law=this.personRules[p.name]||DEFAULT_PERSON,candidates=[];
function bias(kind){return (m.preferences[kind]-50)/65+(STAGE>=39&&this.cognition.learning?clamp(m.knowledge[kind]/12,-.35,.65)*this.cognition.adaptation/100:0)}
if(p.thirst<law.waterAt){const t=this.selectRiver(p);if(t)candidates.push({key:'agua',act:'Buscando agua',target:t.pos,route:t.route,score:this.priority(p.thirst,law.waterAt,t.distance)+.06+bias.call(this,'agua'),info:`Sed ${Math.round(p.thirst)}% · búsqueda personal`})}
if(p.hunger<law.foodAt){const t=this.selectFood(p);if(t)candidates.push({key:'comida',act:'Buscando comida',target:t.pos,route:t.route,score:this.priority(p.hunger,law.foodAt,t.distance)+bias.call(this,'comida'),info:`Hambre ${Math.round(p.hunger)}% · búsqueda personal`})}
if(p.energy<law.restAt)candidates.push({key:'descanso',act:'Descansando',target:null,score:this.priority(p.energy,law.restAt,0)+bias.call(this,'descanso'),info:`Energía ${Math.round(p.energy)}% · descanso`});
candidates.sort((a,b)=>b.score-a.score);let plan=candidates[0];
if(STAGE>=39&&this.cognition.learning&&candidates.length>1&&this.next()<Math.min(.18,this.cognition.adaptation/500))plan=candidates[Math.floor(this.next()*Math.min(candidates.length,2))];
if(!plan){let winner=null;let best=-Infinity;for(let i=0;i<8;i++){const x=clamp(p.x+this.rand(-220,220),20,1420),y=clamp(p.y+this.rand(-220,220),20,940);if(Math.hypot(x-p.x)<40)continue;const route=this.findRoute(p,{x,y});if(!route)continue;const novelty=m.memories.every(z=>Math.hypot(x-z.x,y-z.y)>85)?1:0,score=novelty*.7-route.distance/600+this.rand(0,.08)+bias.call(this,'explorar');if(score>best){best=score;winner={key:'explorar',act:'Explorando',target:{x,y},route,info:'Exploración según preferencias'}}}plan=winner||{key:'explorar',act:'Observando',target:null,info:'Sin destino transitable'};}
p.act=plan.act;p.target=plan.target;p.route=plan.route?.points?.map(a=>({x:a.x,y:a.y}))||[];p.routeIndex=0;p.routeDistance=plan.route?.distance||0;p.goalReason=plan.info;p.decision=plan.target?7:2.5;p.decisionsMade=(p.decisionsMade||0)+1;
if(plan.act==='Descansando')p.stay=4;else if(plan.act==='Observando')p.stay=1.4;
if(m.lastGoal!==plan.key){m.lastGoal=plan.key;if(STAGE>=33)this.note(`${p.name} eligió ${plan.key}: ${plan.info}.`)}
};
proto.complete=function(p){const type=goalOf(p.act),point={x:p.x,y:p.y},item=p.target?.bushId?this.bushes.find(b=>b.id===p.target.bushId):null;
const success=type==='comida'?!!item&&item.fruit>=1:type==='agua'?true:type==='explorar'?true:true;
old.complete.call(this,p);
if(success&&type==='comida')record(this,p,'comida',point.x,point.y,1);
if(success&&type==='agua')record(this,p,'agua',point.x,point.y,1);
if(type==='explorar')record(this,p,'sitio',point.x,point.y,.6);
if(STAGE>=33)reward(this,p,type,success?1:-1);
};
proto.signal=function(from,kind,to){if(STAGE<35)throw Error('Disponible desde 035');if(!['comida','agua','ayuda'].includes(kind))throw Error('Señal no válida');const a=this.people.find(p=>p.name===from&&p.alive!==false),b=this.people.find(p=>p.name===to&&p.alive!==false);if(!a||!b||a===b||Math.hypot(a.x-b.x,a.y-b.y)>210)throw Error('Los habitantes deben estar cerca (210 m)');
const msg={from:a.name,kind,tick:this.tick};ensure(a).communications++;ensure(b).signals.push(msg);ensure(b).signals=ensure(b).signals.slice(-12);this.cognition.totalSignals++;this.note(`${a.name} comunicó «${kind}» a ${b.name}.`);
if(STAGE>=36&&kind!=='ayuda'){const knowledge=ensure(a).memories.filter(m=>m.kind===kind).sort((x,y)=>y.when-x.when).slice(0,2);for(const entry of knowledge){const seen=ensure(b).memories.find(m=>m.kind===kind&&Math.hypot(m.x-entry.x,m.y-entry.y)<30);if(!seen){const z={...entry,from:a.name,strength:Math.max(.3,entry.strength*.8)};ensure(b).memories.push(z);ensure(b).memories=ensure(b).memories.slice(-24);ensure(b).shared++;this.cognition.totalShares++}}}
return msg;};
proto.assist=function(from,to){if(STAGE<37)throw Error('Disponible desde 037');const a=this.people.find(p=>p.name===from&&p.alive!==false),b=this.people.find(p=>p.name===to&&p.alive!==false);if(!a||!b||a===b)throw Error('Elige habitantes distintos');if(Math.hypot(a.x-b.x,a.y-b.y)>210)throw Error('Deben estar a menos de 210 m');const kind=(b.thirst<Math.min(40,this.personRules[b.name]?.waterAt||60))?'agua':'comida';this.signal(a.name,kind,b.name);
let target=kind==='agua'?this.selectRiver(b):this.selectFood(b);if(!target)return false;
if(this.manualName!==b.name){b.target=target.pos;b.route=target.route.points.map(o=>({x:o.x,y:o.y}));b.routeIndex=0;b.routeDistance=target.route.distance;b.act=kind==='agua'?'Buscando agua':'Buscando comida';b.goalReason=`Cooperación con ${a.name}`;b.decision=6;}
ensure(a).cooperations++;this.cognition.totalAid++;this.note(`${a.name} ayudó a orientar a ${b.name}.`);return true;};
proto.cognitionStats=function(){const live=this.people.filter(p=>p.alive!==false);return{people:live.length,memories:live.reduce((s,p)=>s+ensure(p).memories.length,0),attempts:live.reduce((s,p)=>s+Object.values(ensure(p).attempts).reduce((a,b)=>a+b,0),0),signals:this.cognition.totalSignals,shares:this.cognition.totalShares,aids:this.cognition.totalAid}};
proto.step=function(dt=DT){const r=old.step.call(this,dt);if(!this.cognition)return r;
for(const p of this.people.filter(p=>p.alive!==false))ensure(p);
if(STAGE>=34&&this.tick%540===0){for(const p of this.people)if(p.alive!==false){for(const z of ensure(p).memories)z.strength=clamp(z.strength*.985,.05,1);}}
if(STAGE>=35&&this.cognition.signals&&this.tick%180===0){const live=this.people.filter(p=>p.alive!==false);for(const a of live){const receiver=live.find(b=>b!==a&&Math.hypot(b.x-a.x,b.y-a.y)<140);if(!receiver)continue;const kind=a.hunger<(this.personRules[a.name]?.foodAt||60)?'comida':a.thirst<(this.personRules[a.name]?.waterAt||60)?'agua':null;if(!kind)continue;this.signal(a.name,kind,receiver.name);}}
return r};
proto.snapshot=function(){const s=old.snapshot.call(this);s.version=STAGE;s.release=String(STAGE).padStart(3,'0');s.cognition={...this.cognition};s.people=s.people.map(p=>({...p,mind:JSON.parse(JSON.stringify(ensure(p)))}));return s};
proto.load=function(raw){if(!raw||typeof raw!=='object')throw Error('Archivo no válido');const v=raw.version;const r=v>=31&&v<=STAGE?{...raw,version:30}:raw;
old.load.call(this,r);this.cognition={learning:true,signals:true,cooperation:true,adaptation:35,totalSignals:0,totalShares:0,totalAid:0};
if(v>=31&&raw.cognition){for(const k of ['learning','signals','cooperation'])if(typeof raw.cognition[k]==='boolean')this.cognition[k]=raw.cognition[k];for(const k of ['adaptation','totalSignals','totalShares','totalAid'])if(Number.isInteger(raw.cognition[k])&&raw.cognition[k]>=0&&raw.cognition[k]<1e7)this.cognition[k]=raw.cognition[k]}
for(const p of this.people){const original=v>=31?raw.people?.find(x=>x.name===p.name):null;if(original?.mind&&typeof original.mind==='object'){const m=original.mind;p.mind=fresh();for(const key of ['attempts','successes','preferences','knowledge']){for(const k of PREFS){const n=m[key]?.[k];if(Number.isFinite(n)&&n>=-100&&n<=100000)p.mind[key][k]=n;}}p.mind.memories=Array.isArray(m.memories)?m.memories.filter(validSpot).slice(-24).map(x=>({...x,from:String(x.from||'').slice(0,40)})):[];p.mind.signals=Array.isArray(m.signals)?m.signals.slice(-12).filter(z=>z&&typeof z.kind==='string'&&typeof z.from==='string').map(z=>({kind:z.kind.slice(0,12),from:z.from.slice(0,40),tick:Number.isFinite(z.tick)?z.tick:0})):[];for(const k of ['shared','communications','cooperations','seen'])if(Number.isInteger(m[k])&&m[k]>=0&&m[k]<1e6)p.mind[k]=m[k];p.mind.role=typeof m.role==='string'?m.role.slice(0,30):'Explorador';}else ensure(p);}
};
root.GenesisCognition={stage:STAGE,ensure,record};
})(typeof globalThis!=='undefined'?globalThis:this);
