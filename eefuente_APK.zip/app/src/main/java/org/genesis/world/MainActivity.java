package org.genesis.world;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** GÉNESIS 100: visor local. No requiere permiso INTERNET. */
public class MainActivity extends Activity {
    private static final int PICK_JSON = 1301;
    private static final int WRITE_JSON = 1302;
    private static final int MAX_JSON_CHARS = 2_000_000;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String exportPending;
    private boolean selectorAbierto = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showFullscreen();
        web = new WebView(this);
        web.setBackgroundColor(0xff071419);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);
        WebSettings cfg = web.getSettings();
        cfg.setJavaScriptEnabled(true); // Solo página local incluida en APK
        cfg.setDomStorageEnabled(true);
        cfg.setAllowFileAccess(true); // Para file:///android_asset/index.html
        cfg.setAllowContentAccess(true); // Selector Android de documentos JSON
        cfg.setAllowFileAccessFromFileURLs(false);
        cfg.setAllowUniversalAccessFromFileURLs(false);
        cfg.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        cfg.setMediaPlaybackRequiresUserGesture(true);
        cfg.setSupportZoom(false);
        cfg.setBuiltInZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !"file:///android_asset/index.html".equals(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file:///android_asset/index.html".equals(request.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                    startActivityForResult(intent, PICK_JSON);
                    selectorAbierto = true;
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    toast("No se pudo abrir el selector de archivos");
                    return false;
                }
            }
        });
        // Interfaz restringida a los datos de un mundo JSON exportado por el jugador.
        web.addJavascriptInterface(new WorldExporter(), "GenesisAndroid");
        web.loadUrl("file:///android_asset/index.html");
    }

    private final class WorldExporter {
        @JavascriptInterface public void saveWorld(String json) {
            if (json == null || json.length() > MAX_JSON_CHARS) {
                runOnUiThread(() -> toast("Partida demasiado grande para exportar"));
                return;
            }
            runOnUiThread(() -> {
                exportPending = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "genesis_100_4_mundo.json");
                try {
                    selectorAbierto = true;
                    startActivityForResult(intent, WRITE_JSON);
                } catch (Exception e) {
                    exportPending = null;
                    selectorAbierto = false;
                    toast("No se pudo abrir la ventana para guardar");
                }
            });
        }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        selectorAbierto = false;
        if (code == PICK_JSON) {
            if (fileCallback != null) {
                Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
                fileCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
                fileCallback = null;
            }
        } else if (code == WRITE_JSON) {
            String value = exportPending;
            exportPending = null;
            if (result == RESULT_OK && data != null && data.getData() != null && value != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new java.io.IOException("Archivo no escribible");
                    output.write(value.getBytes(StandardCharsets.UTF_8));
                    toast("Mundo exportado como JSON");
                } catch (Exception e) { toast("Error al exportar el mundo"); }
            }
        }
        showFullscreen();
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        showFullscreen();
    }

    @SuppressWarnings("deprecation")
    private void showFullscreen() {
        getWindow().getDecorView().setSystemUiVisibility(
          View.SYSTEM_UI_FLAG_FULLSCREEN |
          View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
          View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
          View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
          View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
          View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (selectorAbierto) { super.onBackPressed(); return; }
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){var s=document.getElementById('genesisSimpleSheet');"+
          "if(s&&!s.hidden){window.GenesisSimple050.close();return true;}"+
          "var r=document.getElementById('genesisRadial');"+
          "if(r&&!r.hidden){document.getElementById('gsWheelCenter').dispatchEvent(new Event('click',{bubbles:true}));return true;}"+
          "var d=document.getElementById('gameDrawer');"+
          "if(d&&!d.hidden){document.getElementById('drawerClose').click();return true;}"+
          "return false})()", value -> {
            if (!"true".equals(value)) new AlertDialog.Builder(this)
                .setTitle("Salir de GÉNESIS")
                .setMessage("¿Cerrar el juego? Puedes guardar tu mundo antes de salir.")
                .setNegativeButton("Seguir jugando", (dialog,which)->{})
                .setPositiveButton("Salir", (dialog,which)->finish()).show();
        });
    }
    @Override protected void onPause() {
        if(web != null) web.evaluateJavascript("try{document.dispatchEvent(new Event('visibilitychange'))}catch(e){}", null);
        super.onPause();
    }
    @Override protected void onDestroy() {
        if (fileCallback != null) {fileCallback.onReceiveValue(null); fileCallback=null;}
        if (web != null) {
            web.removeJavascriptInterface("GenesisAndroid");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
