# GÉNESIS 100.4-A — Fase 1 del Plan Visual Maestro

## Qué cambia en el juego
- **Vista únicamente 2D**. Se ha retirado el código WebGL/3D de exploración y sus botones/sensores; se conserva el mundo y sus guardados.
- **Terreno mejorado:** mezcla de colores y suelos según los biomas reales; ribera suave, colinas dibujadas con volumen, cuatro siluetas de árboles, pasto y piedras distribuidos mediante la semilla del mundo.
- **Gráficos generados en caché**: `GenesisVisual.buildTerrain` crea un solo canvas de terreno; al cambiar biomas o calidad se reconstruye. Los efectos ambientales animados avanzados quedan para fases posteriores.
- **Interfaz radial de 6 sectores conservada**; mapa horizontal, minimapa y controles originales.
- Guardados, planetas, habitantes y reglas originales conservados; se recomienda exportar un JSON antes de cambiar de versión.

## Archivos
- `app/src/main/assets/index.html` es el juego entero sin Internet y es código fuente HTML/JavaScript editable.
- `terrain_fase1.js` contiene la función legible de terreno para estudiar o modificar.
- `fuentes/script_XX.js` incluye copia legible de los 24 scripts incluidos en el HTML.
- `.github/workflows/compilar-apk.yml` compila una **APK de depuración** en GitHub Actions.

## Prueba rápida sin compilar
1. Extrae `GENESIS_100_4_A_codigo_fuente_APK.zip`.
2. Abre `app/src/main/assets/index.html` desde un navegador Android compatible.
3. En horizontal pulsa el botón Menú. Selecciona Naturaleza y comprueba la superficie del mundo. También puedes exportar tu partida desde Partida.

## Compilar APK desde tu móvil (GitHub Actions)
Necesitas Internet y una cuenta de GitHub. **No hay APK previamente compilado en el ZIP.**
1. Instala Termux, luego `pkg install git gh unzip -y`.
2. Extrae el ZIP en una carpeta de proyecto y entra en la carpeta donde está `settings.gradle`.
3. Ejecuta `git init -b main` y `gh auth login`.
4. Configura el autor de Git: `git config user.name "GENESIS"` y `git config user.email "TU_EMAIL_GITHUB"` (sustituye por uno tuyo, no copies literalmente el marcador).
5. Crea un repositorio **privado**: `gh repo create genesis-fase1 --private --source=. --remote=origin`.
6. Ejecuta `git add . && git commit -m "GENESIS fase 1" && git push -u origin main`.
7. En GitHub → Actions → **Compilar APK de GENESIS 100.4-A** → **Run workflow**.
8. Cuando concluya correctamente, descarga el artefacto **GENESIS-100-4-A-APK** y extrae `GENESIS-100-4-A-fase1-debug.apk`.

## Limitaciones honestas
- El APK generado es una aplicación Android **WebView offline**, no un motor Android escrito en C++.
- En el entorno de preparación no hay Android SDK ni Gradle instalados, por lo que **no se ha compilado todavía un APK**.
- 144 Hz es un objetivo de pantalla de tu teléfono; GÉNESIS aún no tiene optimización ni medidas reales para 144 FPS. El control actual de dibujo permite 30 o 60 FPS máximo; el modo 144 vendrá en la fase 9 tras las pruebas.
- El terreno de la fase 1 no puede igualar todavía la imagen conceptual; las mejoras de agua dinámica, edificios, vegetación avanzada e iluminación serán fases siguientes.
- Para guardar en una copia externa usa exportar JSON. Evita desinstalar sin exportar.
