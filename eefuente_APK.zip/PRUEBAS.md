# Resultados de pruebas — GÉNESIS 100.4-A, fase 1

Fecha de la revisión: 18 de octubre de 2026.

## Pasaron (Chromium, entorno de desarrollo)
- Sintaxis de los 24 scripts JavaScript revisada con `node --check`.
- Formato horizontal de 1322 × 604 CSS px con DPR=2, canvas interno de 2644 × 1208 píxeles.
- Menú radial con sus seis categorías; sin canvas `genesis3D` ni renderizador WebGL experimental.
- Terreno cacheado de 1440 × 960; niveles de calidad equilibrado y alto.
- Recuperación de partida versión 100 de GÉNESIS 100.3: 2 habitantes, 2 leyes personales, progreso técnico y datos espaciales presentes.
- Cambiar calidad gráfica no alteró la instantánea de simulación (mundo pausado para comparar el estado en el test).
- Pintar un bioma cambió la clasificación real del suelo y permitió regenerar el terreno 2D.
- Revisión de archivos, XML Android, ausencia de permiso INTERNET y checksum del HTML.
- No se detectaron excepciones JavaScript en las pruebas anteriores.

## Pendientes
- Compilar el APK en GitHub Actions o en un SDK Android completo.
- Instalar el APK y probarlo en el Infinix X6878.
- Medir FPS, temperatura y batería en sesiones largas, especialmente con poblaciones grandes.
- Comparar calidad visual real con la referencia conceptual; aún faltan las fases de agua avanzada, árboles/edificios, iluminación y animaciones.
- Verificar memoria y guardado/importación tras reiniciar físicamente Android.

La fase 1 es una mejora jugable del terreno; no representa haber alcanzado aún el estilo final de la imagen de referencia.
