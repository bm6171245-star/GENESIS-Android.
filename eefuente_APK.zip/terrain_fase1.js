/* GÉNESIS 100.4-A — Fase 01: terreno 2D orgánico.
   Sólo render; biomas, física, recursos, agua transitable y guardados provienen del motor.
   Coordenadas de mundo 1440 x 960. Se reconstruye al cambiar el terreno o la calidad. */
function buildTerrain(sim, quality) {
  const w=1440,h=960,seed=sim.seed>>>0;
  const qualityKey=quality==='alto'?'alto':quality==='economico'?'economico':'equilibrado';
  const base=document.createElement('canvas');base.width=480;base.height=320;
  const low=base.getContext('2d',{alpha:false});
  const pixels=low.createImageData(480,320);const data=pixels.data;
  const colors={
    agua:[27,103,138],bosque:[48,108,64],pradera:[118,148,79],desierto:[192,171,111],
    colina:[121,134,109],tundra:[154,170,158],sabana:[158,158,91]
  };
  function fbm(x,y){return (n2(x/230,y/230,seed+11)-.5)*26+(n2(x/53,y/53,seed+67)-.5)*19+(n2(x/12,y/12,seed+151)-.5)*8}
  function maxCoord(v,maxValue){return Math.max(1,Math.min(maxValue-2,v))}
  function neighborWater(x,y){return sim.biomeAt(Math.max(0,x-12),y)==='agua'||sim.biomeAt(Math.min(w-1,x+12),y)==='agua'||sim.biomeAt(x,Math.max(0,y-12))==='agua'||sim.biomeAt(x,Math.min(h-1,y+12))==='agua'}
  for(let py=0;py<320;py++)for(let px=0;px<480;px++){
    const x=px*3+1.5,y=py*3+1.5,kind=sim.biomeAt(x,y);
    const pal=colors[kind]||colors.pradera;const nr=fbm(x,y);
    const d=(py*480+px)*4;let r=pal[0]+nr,g=pal[1]+nr,b=pal[2]+nr;
    // Disolver bordes visuales sin modificar ni una sola celda del mundo lógico.
    // Mezcla la pintura local con la de los biomas colindantes en un margen corto.
    for(const [ox,oy] of [[-10,0],[10,0],[0,-10],[0,10]]){
      const neighbor=sim.biomeAt(maxCoord(x+ox,w),maxCoord(y+oy,h));
      if(neighbor!==kind){const c2=colors[neighbor]||colors.pradera;
        r=mix(r,c2[0]+nr,.13);g=mix(g,c2[1]+nr,.13);b=mix(b,c2[2]+nr,.13);
      }
    }
    const nearWater=kind!=='agua' && (px%2===0||py%2===0) && neighborWater(x,y);
    if(nearWater){const fac=.23+.19*n2(x/39,y/39,seed+5);r=mix(r,206,fac);g=mix(g,182,fac);b=mix(b,131,fac)}
    if(kind==='agua'){
      const wave=n2(x/46+y/190,y/55,seed+77),depth=(n2(x/110,y/120,seed+22)-.5);
      r+=wave*8-depth*17;g+=wave*21+depth*13;b+=wave*21+depth*16;
    }else if(kind==='colina'){
      const ridge=n2(x/77,y/51,seed+201)-.5;
      r+=ridge*32;g+=ridge*29;b+=ridge*25;
    }
    data[d]=sat(r);data[d+1]=sat(g);data[d+2]=sat(b);data[d+3]=255;
  }
  low.putImageData(pixels,0,0);
  const out=document.createElement('canvas');out.width=w;out.height=h;
  const g=out.getContext('2d',{alpha:false});g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(base,0,0,w,h);
  const rand=random(seed^0x1fc2af39);
  const max=(v,a,b)=>Math.max(a,Math.min(b,v));

  // Terreno quebrado, pastos y pequeñas piedras: detalles estables, no partículas dinámicas.
  const marks=qualityKey==='alto'?14500:qualityKey==='economico'?2900:8400;
  for(let i=0;i<marks;i++){
    const x=rand()*w,y=rand()*h,kind=sim.biomeAt(x,y),p=rand();
    if(kind==='agua')continue;
    if(kind==='bosque'||kind==='pradera'||kind==='sabana'){
      g.strokeStyle=p<.45?'#dfdf9e38':'#164e313f';g.lineWidth=.8;
      g.beginPath();g.moveTo(x,y+3);g.lineTo(x-2,y-2-rand()*4);
      if(p>.4){g.moveTo(x,y+2);g.lineTo(x+2,y-1-rand()*2)}g.stroke();
      if(p>.97){g.fillStyle='#d6bd7e8c';g.fillRect(x,y,1.5,1.5)}
    }else if(kind==='colina'||kind==='tundra'){
      g.fillStyle=p>.45?'#dbdcc04b':'#3d504447';g.beginPath();g.ellipse(x,y,2+rand()*3,1.2+rand()*2,rand()*.6,0,Math.PI*2);g.fill();
    }else {
      g.strokeStyle=p<.5?'#f2dea14d':'#76593b36';g.lineWidth=1;g.beginPath();g.moveTo(x,y);g.lineTo(x+3+rand()*9,y-rand()*2);g.stroke();
    }
  }

  // En cerros auténticos del mapa, siluetas 2D y sombreados simulan elevación.
  const hills=qualityKey==='economico'?55:qualityKey==='alto'?210:125;
  for(let i=0;i<hills;i++){
    const x=rand()*w,y=rand()*h;if(sim.biomeAt(x,y)!=='colina')continue;
    const r=9+rand()*23;
    g.fillStyle='rgba(12,32,26,.16)';g.beginPath();g.ellipse(x+4,y+r*.28,r*1.2,r*.35,0,0,7);g.fill();
    polygon(g,[[x-r,y+5],[x-r*.18,y-r*.53],[x+r*.31,y-r*.86],[x+r,y+4]],'#9a9c82');
    polygon(g,[[x-r*.18,y-r*.53],[x+r*.31,y-r*.86],[x+r*.08,y+4],[x-r,y+5]],'#c8c7a6');
    polygon(g,[[x+r*.31,y-r*.86],[x+r,y+4],[x+r*.08,y+4]],'#616f62');
    g.strokeStyle='#edf0d44d';g.lineWidth=1;g.beginPath();g.moveTo(x-r*.18,y-r*.53);g.lineTo(x+r*.31,y-r*.86);g.stroke();
  }

  // Río: costas orgánicas alineadas a la lógica de sim.riverX / sim.riverWidth.
  // No dibujar agua adicional fuera de las celdas reales: conserva los vados.
  for(const edge of [-1,1]){
    g.beginPath();let active=false;
    for(let y=0;y<h;y+=3){const mid=sim.riverX(y),width=sim.riverWidth(y),x=mid+edge*(width+2);
      if(sim.biomeAt(mid,y)==='agua'){
        if(!active){g.moveTo(x,y);active=true}else g.lineTo(x,y);
      }else active=false;
    }
    g.strokeStyle='#e0d9ae55';g.lineWidth=7;g.stroke();
    g.strokeStyle='#b5e7d077';g.lineWidth=2.2;g.stroke();
  }
  // Corrientes sutiles: dibujos fijos que después se animarán en la fase de agua.
  const currentLines=qualityKey==='alto'?650:qualityKey==='economico'?90:300;
  for(let i=0;i<currentLines;i++){
    const y=rand()*h,mid=sim.riverX(y),wid=sim.riverWidth(y),x=mid+(rand()*1.8-.9)*wid;
    if(sim.biomeAt(x,y)!=='agua')continue;
    g.strokeStyle=rand()<.5?'#caf7e33b':'#0c517b50';g.lineWidth=.8+rand()*.6;
    g.beginPath();g.moveTo(x,y);g.bezierCurveTo(x+3,y+3,x+5,y+6,x+8+rand()*11,y+9);g.stroke();
  }
  // Árboles con copas variadas; decorado fijo según la semilla y sólo en biomas permitidos.
  function detailedTree(x,y,r,biome,shape){
    g.fillStyle='#071f1a55';g.beginPath();g.ellipse(x+r*.34,y+r*.48,r*1.14,r*.43,-.1,0,7);g.fill();
    if(shape===0){ // conífera
      g.fillStyle='#584b37';g.fillRect(x-1,y-r*.42,2, r*1.35);
      polygon(g,[[x-r*.63,y+r*.22],[x,y-r*1.55],[x+r*.61,y+r*.22]],'#174a3a');
      polygon(g,[[x-r*.48,y-r*.16],[x,y-r*1.48],[x+r*.48,y-r*.16]],'#347254');
      polygon(g,[[x-r*.32,y-r*.68],[x,y-r*1.55],[x+r*.32,y-r*.68]],'#659b6f');
      return;
    }
    const palette=biome==='tundra'?['#567b66','#759781','#b8c8b1']:biome==='sabana'?['#557e40','#859c4e','#b8b36b']:
      shape===1?['#175333','#31784a','#7da66b']:shape===2?['#2e6036','#4a8d52','#93b36d']:['#1b5a3c','#487d4a','#8fbb73'];
    g.fillStyle='#55432d';g.fillRect(x-1.4,y-r*.14,2.8,r*.8);
    for(const [dx,dy,rr,col] of [[-r*.5,-r*.14,.69,palette[0]],[r*.37,-r*.1,.70,palette[0]],[-r*.12,-r*.52,.83,palette[1]],[r*.38,-r*.59,.55,palette[1]],[-r*.42,-r*.6,.51,palette[2]]]){
      g.fillStyle=col;g.beginPath();g.arc(x+dx,y+dy,rr*r,0,Math.PI*2);g.fill();
    }
    g.fillStyle='#d5e5ae44';g.beginPath();g.ellipse(x-r*.36,y-r*.91,r*.34,r*.16,-.45,0,Math.PI*2);g.fill();
  }
  const attempts=qualityKey==='alto'?4800:qualityKey==='economico'?850:2800;
  for(let i=0;i<attempts;i++){
    const x=rand()*w,y=rand()*h,k=sim.biomeAt(x,y),chance=rand();
    if(k!=='bosque'&&!(k==='pradera'&&chance<.13)&&!(k==='sabana'&&chance<.24)&&!(k==='tundra'&&chance<.075))continue;
    const shape=k==='tundra'?(rand()<.68?0:3):Math.floor(rand()*4);
    detailedTree(x,y,(k==='bosque'?8:6)+rand()*(qualityKey==='alto'?12:10),k,shape);
  }
  // Senderos de piedra de los vados reales, sin modificar la transitabilidad.
  for(const fordY of sim.fordY()){
    const center=sim.riverX(fordY),r=sim.riverWidth(fordY);
    for(let x=center-r-18;x<center+r+18;x+=9){
      const dx=x+rand()*6,dy=fordY-8+rand()*16;
      g.fillStyle='#0e272455';g.beginPath();g.ellipse(dx+2,dy+3,5.5,3.5,0,0,7);g.fill();
      g.fillStyle=rand()<.5?'#bcbca2':'#9caa95';g.beginPath();g.ellipse(dx,dy,4+rand()*3,2.4+rand()*2,.2,0,7);g.fill();
    }
  }
  if(sim.nature?.worldType==='fantastico'){
    g.fillStyle='#7449a011';g.fillRect(0,0,w,h);
  }
  return out;
}
