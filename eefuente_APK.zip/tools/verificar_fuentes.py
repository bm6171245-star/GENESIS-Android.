from pathlib import Path
import hashlib, subprocess, re, sys, xml.etree.ElementTree as ET
index = Path('app/src/main/assets/index.html')
code = index.read_text(encoding='utf-8')
assert hashlib.sha256(code.encode('utf-8')).hexdigest() == '0e832895ab5f2e6e0cda3926c828f65705aa374ab0ca88953725e5ed7f3a8547', 'El HTML principal fue modificado. Actualiza este hash tras revisar los cambios.'
for marker in ('GenesisNatureAccess', 'GenesisGraphicsDebug', 'GenesisSimple050', 'GenesisCosmos', 'GenesisCivilizationDebug', 'GenesisAndroid', 'genesisSimpleNav', 'data-game-mode'):
    assert marker in code, f'Función ausente: {marker}'
assert code.count('<script') == code.count('</script>'), 'Scripts HTML sin cerrar'
for name in ('app/src/main/AndroidManifest.xml','app/src/main/res/values/styles.xml','app/src/main/res/drawable/ic_genesis_foreground.xml','app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml'):
    ET.parse(name)
assert 'android.permission.INTERNET' not in Path('app/src/main/AndroidManifest.xml').read_text()
print('OK: juego GÉNESIS 100.4-A fase 1, controles, funciones y XML de Android')
