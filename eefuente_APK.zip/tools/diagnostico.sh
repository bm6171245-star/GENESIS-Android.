#!/data/data/com.termux/files/usr/bin/sh
echo 'Proyecto GÉNESIS 050 listo. Para generar APK se necesita Android SDK y Gradle.'
echo 'Recomendación en Android: usa el flujo de GitHub Actions.'
